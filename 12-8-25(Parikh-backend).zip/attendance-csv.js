"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateAttendanceCSV = generateAttendanceCSV;
exports.exportAttendanceCSV = exportAttendanceCSV;
const supabase_js_1 = require("@supabase/supabase-js");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const dayjs_1 = __importDefault(require("dayjs"));
const supabaseUrl = 'https://wcjcvevbeegkgomjkxbk.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjamN2ZXZiZWVna2dvbWpreGJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4Nzc0MzUsImV4cCI6MjA2OTQ1MzQzNX0.s43Zwktw_Omb9P3zR4BJY4WwESak6J_ZnhOtYlp-DkU';
// const supabaseUrl = 'https://api.parikhassociates.in'
// const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyAgCiAgICAicm9sZSI6ICJhbm9uIiwKICAgICJpc3MiOiAic3VwYWJhc2UtZGVtbyIsCiAgICAiaWF0IjogMTY0MTc2OTIwMCwKICAgICJleHAiOiAxNzk5NTM1NjAwCn0.dc_X5iR_VP_qT0zsiyj_I_OZ2T9FtRU2BBNWN8Bu4GE'
const supabase = (0, supabase_js_1.createClient)(supabaseUrl, supabaseAnonKey);
function generateAttendanceCSV(startDate, endDate) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log(`Generating attendance CSV for ${startDate} to ${endDate}...`);
            // Query attendance data
            const { data: attendanceData, error } = yield supabase
                .from('employee_attendance')
                .select('employee_id, attendance_date, status, first_punch_in, notes')
                .gte('attendance_date', startDate)
                .lte('attendance_date', endDate)
                .order('attendance_date', { ascending: true });
            if (error) {
                console.error('Error fetching attendance data:', error);
                return;
            }
            if (!attendanceData || attendanceData.length === 0) {
                console.log('No attendance data found for the specified date range');
                return;
            }
            console.log(`Found ${attendanceData.length} attendance records`);
            // Get unique employee IDs
            const employeeIds = [...new Set(attendanceData.map(record => record.employee_id))];
            // Query employee details
            const { data: employees, error: empError } = yield supabase
                .from('employees')
                .select('id, user_id')
                .in('id', employeeIds);
            if (empError) {
                console.error('Error fetching employee data:', empError);
                return;
            }
            // Get user profile details
            const userIds = (employees === null || employees === void 0 ? void 0 : employees.map(emp => emp.user_id)) || [];
            const { data: userProfiles, error: userError } = yield supabase
                .from('user_profiles')
                .select('id, first_name, last_name, biometric_code')
                .in('id', userIds);
            if (userError) {
                console.error('Error fetching user profile data:', userError);
                return;
            }
            // Create lookup maps
            const employeeMap = new Map((employees === null || employees === void 0 ? void 0 : employees.map(emp => [emp.id, emp.user_id])) || []);
            const userMap = new Map((userProfiles === null || userProfiles === void 0 ? void 0 : userProfiles.map(user => [user.id, user])) || []);
            // Create CSV content
            const csvHeaders = [
                'Employee Name',
                'Biometric Code',
                'Date',
                'Status',
                'First Punch In',
                'Notes'
            ];
            const csvRows = attendanceData.map(record => {
                const userId = employeeMap.get(record.employee_id);
                const userProfile = userMap.get(userId);
                return [
                    `"${(userProfile === null || userProfile === void 0 ? void 0 : userProfile.first_name) || ''} ${(userProfile === null || userProfile === void 0 ? void 0 : userProfile.last_name) || ''}"`,
                    (userProfile === null || userProfile === void 0 ? void 0 : userProfile.biometric_code) || '',
                    record.attendance_date,
                    record.status,
                    record.first_punch_in ? (0, dayjs_1.default)(record.first_punch_in).format('YYYY-MM-DD HH:mm:ss') : '',
                    `"${record.notes || ''}"`
                ].join(',');
            });
            const csvContent = [csvHeaders.join(','), ...csvRows].join('\n');
            // Create filename with timestamp
            const timestamp = (0, dayjs_1.default)().format('YYYY-MM-DD_HH-mm-ss');
            const filename = `attendance_${startDate}_to_${endDate}_${timestamp}.csv`;
            // Save to Downloads folder (common location)
            const downloadsPath = path_1.default.join(process.env.USERPROFILE || process.env.HOME || '', 'Downloads');
            const filePath = path_1.default.join(downloadsPath, filename);
            // Write CSV file
            fs_1.default.writeFileSync(filePath, csvContent, 'utf8');
            console.log(`CSV file saved successfully: ${filePath}`);
            return filePath;
        }
        catch (error) {
            console.error('Error generating CSV:', error);
        }
    });
}
// Function to generate CSV for specific date range
function exportAttendanceCSV(startDate, endDate) {
    return __awaiter(this, void 0, void 0, function* () {
        const filePath = yield generateAttendanceCSV(startDate, endDate);
        if (filePath) {
            console.log(`Attendance CSV exported to: ${filePath}`);
        }
    });
}
