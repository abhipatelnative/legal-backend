"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.processAttendanceToCSV = processAttendanceToCSV;
const supabase_js_1 = require("@supabase/supabase-js");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const dayjs_1 = __importDefault(require("dayjs"));
const crypto_1 = require("crypto");
const supabaseUrl = 'https://wcjcvevbeegkgomjkxbk.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjamN2ZXZiZWVna2dvbWpreGJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4Nzc0MzUsImV4cCI6MjA2OTQ1MzQzNX0.s43Zwktw_Omb9P3zR4BJY4WwESak6J_ZnhOtYlp-DkU';
// const supabaseUrl = 'https://api.parikhassociates.in'
// const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyAgCiAgICAicm9sZSI6ICJhbm9uIiwKICAgICJpc3MiOiAic3VwYWJhc2UtZGVtbyIsCiAgICAiaWF0IjogMTY0MTc2OTIwMCwKICAgICJleHAiOiAxNzk5NTM1NjAwCn0.dc_X5iR_VP_qT0zsiyj_I_OZ2T9FtRU2BBNWN8Bu4GE'
const supabase = (0, supabase_js_1.createClient)(supabaseUrl, supabaseAnonKey);
function processAttendanceToCSV(startDate, endDate) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log(`Processing attendance from punch records for ${startDate} to ${endDate}...`);
            const csvRows = [];
            const csvHeaders = ['id', 'employee_id', 'attendance_date', 'status', 'first_punch_in', 'notes'];
            // Get all active employees
            const { data: employees, error: empError } = yield supabase
                .from('employees')
                .select('id, user_id')
                .eq('is_active', true)
                .eq('employment_status', 'active');
            if (empError || !employees) {
                console.error('Error fetching employees:', empError);
                return;
            }
            // Filter employees with active contracts
            const employeeIds = employees.map(emp => emp.id);
            const { data: contracts } = yield supabase
                .from('contracts')
                .select('employee_id')
                .in('employee_id', employeeIds)
                .eq('status', 'active')
                .eq('is_active', true);
            const activeEmployeeIds = (contracts === null || contracts === void 0 ? void 0 : contracts.map(c => c.employee_id)) || [];
            const activeEmployees = employees.filter(emp => activeEmployeeIds.includes(emp.id));
            // Get user profiles for active employees
            const userIds = activeEmployees.map(emp => emp.user_id);
            const { data: userProfiles } = yield supabase
                .from('user_profiles')
                .select('id, first_name, last_name, biometric_code')
                .in('id', userIds);
            // Create lookup map
            const userMap = new Map((userProfiles === null || userProfiles === void 0 ? void 0 : userProfiles.map(user => [user.id, user])) || []);
            const employeesWithProfiles = activeEmployees.map(emp => (Object.assign(Object.assign({}, emp), { user_profiles: userMap.get(emp.user_id) }))).filter(emp => emp.user_profiles);
            console.log(`Processing ${employeesWithProfiles.length} employees`);
            // Process each date in the range
            const start = (0, dayjs_1.default)(startDate);
            const end = (0, dayjs_1.default)(endDate);
            let currentDate = start;
            while (currentDate.isBefore(end) || currentDate.isSame(end)) {
                const processingDate = currentDate.format('YYYY-MM-DD');
                console.log(`Processing date: ${processingDate}`);
                for (const emp of employeesWithProfiles) {
                    const employee = emp;
                    const userProfile = employee.user_profiles;
                    // Get contract for this employee
                    const { data: contractData } = yield supabase
                        .from('contracts')
                        .select('id')
                        .eq('employee_id', employee.id)
                        .eq('status', 'active')
                        .eq('is_active', true)
                        .limit(1);
                    if (!contractData || contractData.length === 0)
                        continue;
                    const contract = contractData[0];
                    let status = 'Absent';
                    let firstPunchIn = '';
                    // Step 1: Check for approved leave
                    const { data: leaveData } = yield supabase
                        .from('leave_requests')
                        .select('id')
                        .eq('employee_id', employee.id)
                        .eq('status', 'approved')
                        .lte('start_date', processingDate)
                        .gte('end_date', processingDate)
                        .limit(1);
                    if (leaveData && leaveData.length > 0) {
                        status = 'Leave';
                    }
                    else {
                        // Step 2: Check contract-based holidays
                        const { data: holidayData } = yield supabase
                            .from('contract_holidays')
                            .select(`
              holidays!inner(start_date, end_date)
            `)
                            .eq('contract_id', contract.id)
                            .eq('is_applicable', true)
                            .eq('holidays.is_active', true)
                            .lte('holidays.start_date', processingDate)
                            .gte('holidays.end_date', processingDate)
                            .limit(1);
                        if (holidayData && holidayData.length > 0) {
                            status = 'Holiday';
                        }
                        else {
                            // Step 3: Check week-off
                            const dayOfWeek = currentDate.day(); // 0=Sunday, 1=Monday, etc.
                            const { data: shiftData } = yield supabase
                                .from('employee_shifts')
                                .select(`
                work_weeks!inner(sunday, monday, tuesday, wednesday, thursday, friday, saturday)
              `)
                                .eq('employee_id', employee.id)
                                .eq('is_active', true)
                                .limit(1);
                            if (shiftData && shiftData.length > 0) {
                                const workWeek = shiftData[0].work_weeks;
                                const dayFields = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
                                const isWorkingDay = workWeek[dayFields[dayOfWeek]];
                                if (!isWorkingDay) {
                                    status = 'WeekOff';
                                }
                                else {
                                    // Step 4: Check punch records
                                    const { data: punchData } = yield supabase
                                        .from('punch_records')
                                        .select('punch_time')
                                        .eq('enroll_number', parseInt(userProfile.biometric_code))
                                        .gte('punch_time', `${processingDate} 00:00:00`)
                                        .lt('punch_time', `${currentDate.add(1, 'day').format('YYYY-MM-DD')} 00:00:00`)
                                        .order('punch_time', { ascending: true });
                                    if (punchData && punchData.length > 0) {
                                        status = 'Present';
                                        firstPunchIn = (0, dayjs_1.default)(punchData[0].punch_time).format('HH:mm:ss');
                                    }
                                }
                            }
                            else {
                                // No shift data, check punch records anyway
                                const { data: punchData } = yield supabase
                                    .from('punch_records')
                                    .select('punch_time')
                                    .eq('enroll_number', parseInt(userProfile.biometric_code))
                                    .gte('punch_time', `${processingDate} 00:00:00`)
                                    .lt('punch_time', `${currentDate.add(1, 'day').format('YYYY-MM-DD')} 00:00:00`)
                                    .order('punch_time', { ascending: true });
                                if (punchData && punchData.length > 0) {
                                    status = 'Present';
                                    firstPunchIn = (0, dayjs_1.default)(punchData[0].punch_time).format('HH:mm:ss');
                                }
                            }
                        }
                    }
                    // Add row to CSV
                    csvRows.push([
                        (0, crypto_1.randomUUID)(),
                        employee.id,
                        processingDate,
                        status,
                        firstPunchIn,
                        ''
                    ].join(','));
                }
                currentDate = currentDate.add(1, 'day');
            }
            // Create CSV content
            const csvContent = [csvHeaders.join(','), ...csvRows].join('\n');
            // Create filename with timestamp
            const timestamp = (0, dayjs_1.default)().format('YYYY-MM-DD_HH-mm-ss');
            const filename = `employee_attendance_${startDate}_to_${endDate}_${timestamp}.csv`;
            // Save to Downloads folder
            const downloadsPath = path_1.default.join(process.env.USERPROFILE || process.env.HOME || '', 'Downloads');
            const filePath = path_1.default.join(downloadsPath, filename);
            // Write CSV file
            fs_1.default.writeFileSync(filePath, csvContent, 'utf8');
            console.log(`Attendance CSV processed and saved: ${filePath}`);
            console.log(`Total records: ${csvRows.length}`);
            return filePath;
        }
        catch (error) {
            console.error('Error processing attendance to CSV:', error);
        }
    });
}
