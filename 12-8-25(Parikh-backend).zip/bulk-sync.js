"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const punch_sync_1 = require("./punch-sync");
function runBulkSync() {
    return __awaiter(this, void 0, void 0, function* () {
        console.log('Starting bulk sync of all punch records...');
        yield (0, punch_sync_1.syncAllPunchRecords)();
        console.log('Bulk sync completed!');
        process.exit(0);
    });
}
runBulkSync().catch(console.error);
