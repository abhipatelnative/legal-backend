"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSmtpSettings = getSmtpSettings;
exports.sendEventNotificationEmail = sendEventNotificationEmail;
exports.testSmtpConnection = testSmtpConnection;
exports.sendTestEmailToAddress = sendTestEmailToAddress;
exports.logEventNotification = logEventNotification;
exports.hasNotificationBeenSent = hasNotificationBeenSent;
const nodemailer_1 = __importDefault(require("nodemailer"));
const supabase_js_1 = require("@supabase/supabase-js");
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
// Supabase client
// const supabaseUrl =  'https://api.parikhassociates.in';
// const supabaseAnonKey =  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyAgCiAgICAicm9sZSI6ICJhbm9uIiwKICAgICJpc3MiOiAic3VwYWJhc2UtZGVtbyIsCiAgICAiaWF0IjogMTY0MTc2OTIwMCwKICAgICJleHAiOiAxNzk5NTM1NjAwCn0.dc_X5iR_VP_qT0zsiyj_I_OZ2T9FtRU2BBNWN8Bu4GE';
const supabaseUrl = 'https://wcjcvevbeegkgomjkxbk.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjamN2ZXZiZWVna2dvbWpreGJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4Nzc0MzUsImV4cCI6MjA2OTQ1MzQzNX0.s43Zwktw_Omb9P3zR4BJY4WwESak6J_ZnhOtYlp-DkU';
const supabase = (0, supabase_js_1.createClient)(supabaseUrl, supabaseAnonKey);
/**
 * Get active SMTP settings from database
 */
function getSmtpSettings() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { data, error } = yield supabase
                .from('smtp_settings')
                .select('*')
                .eq('is_deleted', false)
                .eq('is_active', true)
                .maybeSingle();
            if (error) {
                console.error('Error fetching SMTP settings:', error);
                return null;
            }
            if (!data) {
                console.log('No active SMTP settings found');
                return null;
            }
            return {
                host: data.host,
                port: data.port,
                username: data.username,
                password: data.password,
                encryption: data.encryption || 'tls',
                from_email: data.from_email,
                from_name: data.from_name || 'Company',
                days_before_event: data.days_before_event || 7,
                enable_event_notifications: data.enable_event_notifications !== false,
            };
        }
        catch (error) {
            console.error('Error in getSmtpSettings:', error);
            return null;
        }
    });
}
/**
 * Create nodemailer transporter from SMTP settings
 */
function createTransporter(settings) {
    const config = {
        host: settings.host,
        port: settings.port,
        secure: settings.encryption === 'ssl',
        auth: {
            user: settings.username,
            pass: settings.password,
        },
    };
    if (settings.encryption === 'tls') {
        config.requireTLS = true;
    }
    return nodemailer_1.default.createTransport(config);
}
/**
 * Send event notification email to an employee
 */
function sendEventNotificationEmail(employee, event, smtpSettings) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const transporter = createTransporter(smtpSettings);
            // Format event date
            const eventDate = new Date(event.start_date);
            const formattedDate = eventDate.toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
            });
            // Format event type
            const eventTypeLabels = {
                company: 'Company Event',
                holiday: 'Holiday',
                meeting: 'Meeting',
                celebration: 'Celebration',
                other: 'Event',
            };
            const eventTypeLabel = eventTypeLabels[event.event_type] || 'Event';
            // Create email subject
            const subject = `Upcoming ${eventTypeLabel}: ${event.title}`;
            // Create email body
            const htmlBody = `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #4F46E5; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
          .content { background-color: #f9fafb; padding: 30px; border-radius: 0 0 5px 5px; }
          .event-card { background-color: white; padding: 20px; margin: 20px 0; border-left: 4px solid #4F46E5; border-radius: 4px; }
          .event-title { font-size: 24px; font-weight: bold; color: #1f2937; margin-bottom: 10px; }
          .event-date { font-size: 18px; color: #4F46E5; margin-bottom: 15px; }
          .event-description { color: #6b7280; margin-top: 10px; }
          .footer { text-align: center; margin-top: 30px; color: #9ca3af; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Upcoming ${eventTypeLabel}</h1>
          </div>
          <div class="content">
            <p>Dear Employee,</p>
            <p>This is a reminder about an upcoming ${eventTypeLabel.toLowerCase()}:</p>
            
            <div class="event-card">
              <div class="event-title">${event.title}</div>
              <div class="event-date">📅 ${formattedDate}</div>
              ${event.description ? `<div class="event-description">${event.description}</div>` : ''}
            </div>
            
            <p>Please mark your calendar and plan accordingly.</p>
            
            <div class="footer">
              <p>This is an automated notification from your HR system.</p>
              <p>Please do not reply to this email.</p>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;
            const textBody = `
Upcoming ${eventTypeLabel}: ${event.title}

Date: ${formattedDate}
${event.description ? `Description: ${event.description}` : ''}

Please mark your calendar and plan accordingly.

This is an automated notification from your HR system.
    `;
            const mailOptions = {
                from: `"${smtpSettings.from_name}" <${smtpSettings.from_email}>`,
                to: employee.company_email,
                subject: subject,
                text: textBody,
                html: htmlBody,
            };
            const info = yield transporter.sendMail(mailOptions);
            console.log(`Email sent successfully to ${employee.company_email} for event ${event.id}:`, info.messageId);
            return true;
        }
        catch (error) {
            console.error(`Error sending email to ${employee.company_email} for event ${event.id}:`, error);
            return false;
        }
    });
}
/**
 * Test SMTP connection and send a test email
 */
function testSmtpConnection() {
    return __awaiter(this, arguments, void 0, function* (sendTestEmail = false) {
        try {
            console.log('Testing SMTP configuration...');
            const smtpSettings = yield getSmtpSettings();
            if (!smtpSettings) {
                return {
                    success: false,
                    message: 'No SMTP settings found. Please configure SMTP settings in the admin panel.'
                };
            }
            // Create transporter
            const transporter = createTransporter(smtpSettings);
            // Test connection
            console.log('Verifying SMTP connection...');
            yield transporter.verify();
            console.log('✓ SMTP connection verified successfully');
            if (sendTestEmail) {
                // Get first active employee email for test
                const { data: employees } = yield supabase
                    .from('employees')
                    .select('company_email')
                    .eq('is_active', true)
                    .eq('is_deleted', false)
                    .limit(1);
                const testEmail = employees && employees.length > 0
                    ? employees[0].company_email
                    : smtpSettings.from_email;
                const testMailOptions = {
                    from: `"${smtpSettings.from_name}" <${smtpSettings.from_email}>`,
                    to: testEmail,
                    subject: 'Test Email - Event Notification System',
                    text: 'This is a test email from the Event Notification System. If you receive this, the email configuration is working correctly.',
                    html: `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
              .container { max-width: 600px; margin: 0 auto; padding: 20px; }
              .header { background-color: #4F46E5; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
              .content { background-color: #f9fafb; padding: 30px; border-radius: 0 0 5px 5px; }
              .success { color: #10b981; font-weight: bold; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <h1>✓ Email Test Successful</h1>
              </div>
              <div class="content">
                <p>This is a test email from the Event Notification System.</p>
                <p class="success">If you receive this email, your SMTP configuration is working correctly!</p>
                <p>The system will automatically send event notifications to employees based on your configured settings.</p>
                <p><strong>Notification Settings:</strong></p>
                <ul>
                  <li>Days before event: ${smtpSettings.days_before_event} days</li>
                  <li>From: ${smtpSettings.from_name} &lt;${smtpSettings.from_email}&gt;</li>
                </ul>
              </div>
            </div>
          </body>
          </html>
        `,
                };
                console.log(`Sending test email to ${testEmail}...`);
                const info = yield transporter.sendMail(testMailOptions);
                console.log(`✓ Test email sent successfully! Message ID: ${info.messageId}`);
                return {
                    success: true,
                    message: `SMTP connection verified and test email sent successfully to ${testEmail}`
                };
            }
            return {
                success: true,
                message: 'SMTP connection verified successfully'
            };
        }
        catch (error) {
            console.error('✗ SMTP test failed:', error);
            return {
                success: false,
                message: `SMTP test failed: ${error.message || 'Unknown error'}`
            };
        }
    });
}
/**
 * Send a test email to a specific email address
 */
function sendTestEmailToAddress(emailAddress) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log(`Sending test email to ${emailAddress}...`);
            const smtpSettings = yield getSmtpSettings();
            if (!smtpSettings) {
                return {
                    success: false,
                    message: 'No SMTP settings found. Please configure SMTP settings in the admin panel.'
                };
            }
            // Validate email address
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(emailAddress)) {
                return {
                    success: false,
                    message: 'Invalid email address format.'
                };
            }
            // Create transporter
            const transporter = createTransporter(smtpSettings);
            // Test connection first
            console.log('Verifying SMTP connection...');
            yield transporter.verify();
            console.log('✓ SMTP connection verified successfully');
            const testMailOptions = {
                from: `"${smtpSettings.from_name}" <${smtpSettings.from_email}>`,
                to: emailAddress,
                subject: 'Test Email - Event Notification System',
                text: 'This is a test email from the Event Notification System. If you receive this, the email configuration is working correctly.',
                html: `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #4F46E5; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
          .content { background-color: #f9fafb; padding: 30px; border-radius: 0 0 5px 5px; }
          .success { color: #10b981; font-weight: bold; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>✓ Email Test Successful</h1>
          </div>
          <div class="content">
            <p>This is a test email from the Event Notification System.</p>
            <p class="success">If you receive this email, your SMTP configuration is working correctly!</p>
            <p>The system will automatically send event notifications to employees based on your configured settings.</p>
            <p><strong>Notification Settings:</strong></p>
            <ul>
              <li>Days before event: ${smtpSettings.days_before_event} days</li>
              <li>From: ${smtpSettings.from_name} &lt;${smtpSettings.from_email}&gt;</li>
              <li>Event notifications: ${smtpSettings.enable_event_notifications ? 'Enabled' : 'Disabled'}</li>
            </ul>
          </div>
        </div>
      </body>
      </html>
    `,
            };
            console.log(`Sending test email to ${emailAddress}...`);
            const info = yield transporter.sendMail(testMailOptions);
            console.log(`✓ Test email sent successfully! Message ID: ${info.messageId}`);
            return {
                success: true,
                message: `Test email sent successfully to ${emailAddress}`
            };
        }
        catch (error) {
            console.error(`✗ Failed to send test email to ${emailAddress}:`, error);
            return {
                success: false,
                message: `Failed to send test email: ${error.message || 'Unknown error'}`
            };
        }
    });
}
/**
 * Log event notification in database
 */
function logEventNotification(eventId, employeeId, notificationDate, eventDate, emailStatus, errorMessage) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { error } = yield supabase
                .from('event_notification_log')
                .insert({
                event_id: eventId,
                employee_id: employeeId,
                notification_date: notificationDate,
                event_date: eventDate,
                email_status: emailStatus,
                error_message: errorMessage || null,
            });
            if (error) {
                console.error('Error logging event notification:', error);
            }
        }
        catch (error) {
            console.error('Error in logEventNotification:', error);
        }
    });
}
/**
 * Check if notification was already sent for this event and employee
 */
function hasNotificationBeenSent(eventId, employeeId, notificationDate) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { data, error } = yield supabase
                .from('event_notification_log')
                .select('id')
                .eq('event_id', eventId)
                .eq('employee_id', employeeId)
                .eq('notification_date', notificationDate)
                .eq('email_status', 'sent')
                .maybeSingle();
            if (error) {
                console.error('Error checking notification log:', error);
                return false;
            }
            return !!data;
        }
        catch (error) {
            console.error('Error in hasNotificationBeenSent:', error);
            return false;
        }
    });
}
