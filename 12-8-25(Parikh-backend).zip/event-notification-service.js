"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendEventNotifications = sendEventNotifications;
const dayjs_1 = __importDefault(require("dayjs"));
const supabase_js_1 = require("@supabase/supabase-js");
const dotenv_1 = __importDefault(require("dotenv"));
const email_service_1 = require("./email-service");
dotenv_1.default.config();
// Supabase client
// const supabaseUrl =  'https://api.parikhassociates.in';
// const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyAgCiAgICAicm9sZSI6ICJhbm9uIiwKICAgICJpc3MiOiAic3VwYWJhc2UtZGVtbyIsCiAgICAiaWF0IjogMTY0MTc2OTIwMCwKICAgICJleHAiOiAxNzk5NTM1NjAwCn0.dc_X5iR_VP_qT0zsiyj_I_OZ2T9FtRU2BBNWN8Bu4GE';
const supabaseUrl = 'https://wcjcvevbeegkgomjkxbk.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjamN2ZXZiZWVna2dvbWpreGJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4Nzc0MzUsImV4cCI6MjA2OTQ1MzQzNX0.s43Zwktw_Omb9P3zR4BJY4WwESak6J_ZnhOtYlp-DkU';
const supabase = (0, supabase_js_1.createClient)(supabaseUrl, supabaseAnonKey);
/**
 * Calculate the actual event date for recurring events
 * For recurring events, we need to calculate the next occurrence
 */
function calculateEventDate(event, currentYear) {
    if (!event.is_recurring) {
        return event.start_date;
    }
    // For recurring events, calculate the date for the current year
    const originalDate = (0, dayjs_1.default)(event.start_date);
    const currentDate = (0, dayjs_1.default)();
    // Get the month and day from the original event
    const month = originalDate.month();
    const day = originalDate.date();
    // Create date for current year
    let eventDate = (0, dayjs_1.default)().year(currentYear).month(month).date(day);
    // If the date has already passed this year, use next year
    if (eventDate.isBefore(currentDate, 'day')) {
        eventDate = eventDate.add(1, 'year');
    }
    return eventDate.format('YYYY-MM-DD');
}
/**
 * Get the event date to use for notification (handles recurring events)
 */
function getEventDateForNotification(event) {
    if (!event.is_recurring) {
        return event.start_date;
    }
    const currentYear = (0, dayjs_1.default)().year();
    return calculateEventDate(event, currentYear);
}
/**
 * Check if an event should trigger notifications today
 */
function shouldSendNotificationToday(event, daysBefore, currentYear) {
    const eventDate = calculateEventDate(event, currentYear);
    const today = (0, dayjs_1.default)();
    const targetDate = (0, dayjs_1.default)(eventDate);
    const daysUntilEvent = targetDate.diff(today, 'day');
    // Send notification if event is exactly 'daysBefore' days away
    return daysUntilEvent === daysBefore;
}
/**
 * Get all active employees
 */
function getActiveEmployees() {
    return __awaiter(this, arguments, void 0, function* (branchId = null) {
        try {
            let query = supabase
                .from('employees')
                .select('id, company_email, user_id, branch_id')
                .eq('is_active', true)
                .eq('is_deleted', false);
            // Filter by branch if specified
            if (branchId) {
                query = query.eq('branch_id', branchId);
            }
            const { data, error } = yield query;
            if (error) {
                console.error('Error fetching employees:', error);
                return [];
            }
            return data || [];
        }
        catch (error) {
            console.error('Error in getActiveEmployees:', error);
            return [];
        }
    });
}
/**
 * Get upcoming events that need notifications
 */
function getUpcomingEvents(daysBefore) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const today = (0, dayjs_1.default)();
            const currentYear = today.year();
            const nextYear = currentYear + 1;
            // Get all active events (including recurring ones)
            const { data, error } = yield supabase
                .from('company_events')
                .select('*')
                .eq('is_active', true)
                .eq('is_deleted', false)
                .order('start_date', { ascending: true });
            if (error) {
                console.error('Error fetching events:', error);
                return [];
            }
            if (!data) {
                return [];
            }
            // Filter events that should trigger notifications today
            const eventsToNotify = [];
            for (const event of data) {
                // Check current year
                if (shouldSendNotificationToday(event, daysBefore, currentYear)) {
                    eventsToNotify.push(event);
                    continue;
                }
                // For recurring events, also check next year
                if (event.is_recurring && shouldSendNotificationToday(event, daysBefore, nextYear)) {
                    eventsToNotify.push(event);
                }
            }
            return eventsToNotify;
        }
        catch (error) {
            console.error('Error in getUpcomingEvents:', error);
            return [];
        }
    });
}
/**
 * Send event notifications for all upcoming events
 */
function sendEventNotifications() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log('Starting event notification process...');
            // Get SMTP settings
            const smtpSettings = yield (0, email_service_1.getSmtpSettings)();
            if (!smtpSettings) {
                console.log('No SMTP settings found. Skipping event notifications.');
                return;
            }
            // Check if event notifications are enabled
            if (!smtpSettings.enable_event_notifications) {
                console.log('Event notifications are disabled in SMTP settings. Skipping event notifications.');
                return;
            }
            const daysBefore = smtpSettings.days_before_event || 7;
            console.log(`Checking for events ${daysBefore} days in advance...`);
            // Get upcoming events
            const events = yield getUpcomingEvents(daysBefore);
            console.log(`Found ${events.length} events to notify about`);
            if (events.length === 0) {
                console.log('No events require notifications today.');
                return;
            }
            const today = (0, dayjs_1.default)().format('YYYY-MM-DD');
            let totalSent = 0;
            let totalFailed = 0;
            // Process each event
            for (const event of events) {
                console.log(`Processing event: ${event.title} (ID: ${event.id})`);
                // Calculate actual event date (handles recurring events)
                const eventDate = getEventDateForNotification(event);
                // Get employees for this event
                // If event has a branch_id, only notify employees from that branch
                // If branch_id is null, notify all employees
                const employees = yield getActiveEmployees(event.branch_id || null);
                console.log(`Found ${employees.length} employees to notify for event ${event.title}`);
                // Send notification to each employee
                for (const employee of employees) {
                    // Check if notification was already sent
                    const alreadySent = yield (0, email_service_1.hasNotificationBeenSent)(event.id, employee.id, today);
                    if (alreadySent) {
                        console.log(`Notification already sent to ${employee.company_email} for event ${event.id}`);
                        continue;
                    }
                    // Send email
                    const success = yield (0, email_service_1.sendEventNotificationEmail)(employee, Object.assign(Object.assign({}, event), { start_date: eventDate }), smtpSettings);
                    // Log the notification
                    yield (0, email_service_1.logEventNotification)(event.id, employee.id, today, eventDate, success ? 'sent' : 'failed', success ? undefined : 'Failed to send email');
                    if (success) {
                        totalSent++;
                        console.log(`✓ Notification sent to ${employee.company_email}`);
                    }
                    else {
                        totalFailed++;
                        console.log(`✗ Failed to send notification to ${employee.company_email}`);
                    }
                    // Small delay to avoid overwhelming the email server
                    yield new Promise(resolve => setTimeout(resolve, 100));
                }
            }
            console.log(`Event notification process completed. Sent: ${totalSent}, Failed: ${totalFailed}`);
        }
        catch (error) {
            console.error('Error in sendEventNotifications:', error);
        }
    });
}
