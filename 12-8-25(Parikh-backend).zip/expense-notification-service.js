"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendExpenseNotifications = sendExpenseNotifications;
exports.notifyExpenseSubmitted = notifyExpenseSubmitted;
exports.notifyExpenseApproved = notifyExpenseApproved;
exports.notifyExpenseRejected = notifyExpenseRejected;
const supabase_js_1 = require("@supabase/supabase-js");
const dotenv_1 = __importDefault(require("dotenv"));
const web_push_service_1 = require("./web-push-service");
dotenv_1.default.config();
// Supabase client
const supabaseUrl = 'https://wcjcvevbeegkgomjkxbk.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjamN2ZXZiZWVna2dvbWpreGJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4Nzc0MzUsImV4cCI6MjA2OTQ1MzQzNX0.s43Zwktw_Omb9P3zR4BJY4WwESak6J_ZnhOtYlp-DkU';
const supabase = (0, supabase_js_1.createClient)(supabaseUrl, supabaseAnonKey);
/**
 * Send expense notifications to HR Manager, Manager, and Admin users
 */
function sendExpenseNotifications(notificationData) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { expenseId, expenseNumber, amount, description, categoryName, status, submittedBy, approvedBy, rejectedBy, rejectionReason, branchId } = notificationData;
            // Get Admin, Manager, and HR user IDs
            const { data: adminUserIds, error: userError } = yield supabase.rpc('get_admin_user_ids_for_notifications');
            if (userError) {
                console.error('Error fetching admin user IDs:', userError);
                return {
                    success: false,
                    message: `Failed to fetch admin user IDs: ${userError.message}`,
                    notificationsCreated: 0,
                    pushSent: 0
                };
            }
            if (!adminUserIds || adminUserIds.length === 0) {
                console.log('⚠️  No admin/manager/HR users found - notifications will not be sent');
                return {
                    success: true,
                    message: 'No admin/manager/HR users found',
                    notificationsCreated: 0,
                    pushSent: 0
                };
            }
            // Log which users are eligible to receive notifications
            console.log(`\n📋 Found ${adminUserIds.length} eligible user(s) for expense notifications:`);
            const userIds = adminUserIds.map((row) => row.user_id);
            console.log(`   User IDs: ${userIds.join(', ')}`);
            // Get company logo URL
            let logoUrl = '/logo.png'; // fallback
            try {
                const { data: companySettings } = yield supabase
                    .from('company_settings')
                    .select('logo_url')
                    .single();
                if (companySettings === null || companySettings === void 0 ? void 0 : companySettings.logo_url) {
                    logoUrl = companySettings.logo_url;
                }
            }
            catch (logoError) {
                console.log('Could not fetch company logo, using fallback');
            }
            // Try to get user details (email/name) for better logging
            try {
                const { data: userDetails } = yield supabase
                    .from('user_profiles')
                    .select('id, first_name, last_name')
                    .in('id', userIds);
                if (userDetails && userDetails.length > 0) {
                    console.log(`\n👥 Eligible users details:`);
                    userDetails.forEach((user) => {
                        const fullName = `${user.first_name || ''} ${user.last_name || ''}`.trim();
                        console.log(`   - ${fullName || user.id}`);
                    });
                }
            }
            catch (detailError) {
                console.log('   (Could not fetch user details for logging)');
            }
            // Prepare notification message and title based on status
            let title = '';
            let message = '';
            let actionUrl = '';
            let referenceType = '';
            switch (status) {
                case 'submitted':
                    title = 'New Expense Submitted';
                    message = `💰 New expense ${expenseNumber} submitted: ${formatCurrency(amount)} - ${description.substring(0, 50)}${description.length > 50 ? '...' : ''}`;
                    actionUrl = `/expenses?expense=${expenseId}`;
                    referenceType = 'expense_submitted';
                    break;
                case 'approved':
                    title = 'Expense Approved';
                    message = `✅ Expense ${expenseNumber} has been approved: ${formatCurrency(amount)} - ${description.substring(0, 50)}${description.length > 50 ? '...' : ''}`;
                    actionUrl = `/expenses?expense=${expenseId}`;
                    referenceType = 'expense_approved';
                    break;
                case 'rejected':
                    title = 'Expense Rejected';
                    message = `❌ Expense ${expenseNumber} has been rejected: ${formatCurrency(amount)} - ${description.substring(0, 50)}${description.length > 50 ? '...' : ''}`;
                    if (rejectionReason) {
                        message += ` Reason: ${rejectionReason.substring(0, 30)}${rejectionReason.length > 30 ? '...' : ''}`;
                    }
                    actionUrl = `/expenses?expense=${expenseId}`;
                    referenceType = 'expense_rejected';
                    break;
            }
            // Prepare notification data for database
            const notificationsToInsert = adminUserIds.map((row) => ({
                user_id: row.user_id,
                title: title,
                message: message,
                type: 'expense',
                action_url: actionUrl,
                data: {
                    expense_id: expenseId,
                    expense_number: expenseNumber,
                    amount: amount,
                    description: description,
                    category_name: categoryName,
                    status: status,
                    submitted_by: submittedBy,
                    approved_by: approvedBy,
                    rejected_by: rejectedBy,
                    rejection_reason: rejectionReason,
                    branch_id: branchId,
                    reference_type: referenceType
                }
            }));
            // Insert notifications into database
            const { data: insertedNotifications, error: insertError } = yield supabase.rpc('insert_notifications_for_users', {
                p_notifications: notificationsToInsert
            });
            if (insertError) {
                console.error('Error inserting notifications:', insertError);
                return {
                    success: false,
                    message: `Failed to insert notifications: ${insertError.message}`,
                    notificationsCreated: 0,
                    pushSent: 0
                };
            }
            const notificationsCreated = (insertedNotifications === null || insertedNotifications === void 0 ? void 0 : insertedNotifications.length) || 0;
            console.log(`\n✅ Created ${notificationsCreated} notification(s) in database for expense ${status}`);
            if (notificationsCreated === 0) {
                console.log(`   ⚠️  WARNING: No notifications were created in database!`);
            }
            else if (notificationsCreated < userIds.length) {
                console.log(`   ⚠️  WARNING: Expected ${userIds.length} notifications but only ${notificationsCreated} were created`);
            }
            // Send push notifications
            console.log(`\n📲 Sending push notifications to ${userIds.length} user(s)...`);
            const pushResult = yield (0, web_push_service_1.sendPushNotificationsToUsers)(userIds, {
                title: title,
                message: message,
                url: actionUrl,
                icon: logoUrl,
                badge: logoUrl
            });
            console.log(`\n📊 Push Notification Summary:`);
            console.log(`   ✅ Successfully sent: ${pushResult.success}`);
            console.log(`   ❌ Failed: ${pushResult.failed}`);
            if (pushResult.errors && pushResult.errors.length > 0) {
                console.log(`\n   ❌ Push notification errors:`);
                pushResult.errors.forEach((error, index) => {
                    console.log(`      ${index + 1}. ${error}`);
                });
            }
            if (pushResult.success === 0 && userIds.length > 0) {
                console.log(`\n   ⚠️  WARNING: No push notifications were sent!`);
                console.log(`   Possible reasons:`);
                console.log(`   - Users have not subscribed to push notifications`);
                console.log(`   - Push subscriptions are invalid or expired`);
                console.log(`   - VAPID keys are not configured correctly`);
            }
            return {
                success: true,
                message: `Notifications created and push notifications sent`,
                notificationsCreated: notificationsCreated,
                pushSent: pushResult.success
            };
        }
        catch (error) {
            console.error('Error in sendExpenseNotifications:', error);
            return {
                success: false,
                message: error.message || 'Failed to send expense notifications',
                notificationsCreated: 0,
                pushSent: 0
            };
        }
    });
}
/**
 * Send notification when an expense is submitted/added
 */
function notifyExpenseSubmitted(expenseId, expenseNumber, amount, description, categoryName, submittedBy, branchId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const result = yield sendExpenseNotifications({
                expenseId,
                expenseNumber,
                amount,
                description,
                categoryName,
                status: 'submitted',
                submittedBy,
                branchId
            });
            return {
                success: result.success,
                message: result.message,
                notificationSent: result.notificationsCreated > 0
            };
        }
        catch (error) {
            console.error('Error in notifyExpenseSubmitted:', error);
            return {
                success: false,
                message: error.message || 'Failed to notify expense submission',
                notificationSent: false
            };
        }
    });
}
/**
 * Send notification when an expense is approved
 */
function notifyExpenseApproved(expenseId, expenseNumber, amount, description, categoryName, approvedBy, branchId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const result = yield sendExpenseNotifications({
                expenseId,
                expenseNumber,
                amount,
                description,
                categoryName,
                status: 'approved',
                approvedBy,
                branchId
            });
            return {
                success: result.success,
                message: result.message,
                notificationSent: result.notificationsCreated > 0
            };
        }
        catch (error) {
            console.error('Error in notifyExpenseApproved:', error);
            return {
                success: false,
                message: error.message || 'Failed to notify expense approval',
                notificationSent: false
            };
        }
    });
}
/**
 * Send notification when an expense is rejected
 */
function notifyExpenseRejected(expenseId, expenseNumber, amount, description, rejectionReason, categoryName, rejectedBy, branchId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const result = yield sendExpenseNotifications({
                expenseId,
                expenseNumber,
                amount,
                description,
                categoryName,
                status: 'rejected',
                rejectedBy,
                rejectionReason,
                branchId
            });
            return {
                success: result.success,
                message: result.message,
                notificationSent: result.notificationsCreated > 0
            };
        }
        catch (error) {
            console.error('Error in notifyExpenseRejected:', error);
            return {
                success: false,
                message: error.message || 'Failed to notify expense rejection',
                notificationSent: false
            };
        }
    });
}
/**
 * Helper function to format currency
 */
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
    }).format(amount);
}
