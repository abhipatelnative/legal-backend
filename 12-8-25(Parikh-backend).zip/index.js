"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_cron_1 = __importDefault(require("node-cron"));
const dotenv_1 = __importDefault(require("dotenv"));
const dayjs_1 = __importDefault(require("dayjs"));
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const supabase_js_1 = require("@supabase/supabase-js");
const customParseFormat_1 = __importDefault(require("dayjs/plugin/customParseFormat"));
const mysql_connection_1 = require("./mysql-connection");
const punch_sync_1 = require("./punch-sync");
const event_notification_service_1 = require("./event-notification-service");
const email_service_1 = require("./email-service");
const web_push_service_1 = require("./web-push-service");
const low_stock_notification_service_1 = require("./low-stock-notification-service");
const expense_notification_service_1 = require("./expense-notification-service");
dotenv_1.default.config();
dayjs_1.default.extend(customParseFormat_1.default);
// Supabase client
// const supabaseUrl = 'https://api.parikhassociates.in'
// const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyAgCiAgICAicm9sZSI6ICJhbm9uIiwKICAgICJpc3MiOiAic3VwYWJhc2UtZGVtbyIsCiAgICAiaWF0IjogMTY0MTc2OTIwMCwKICAgICJleHAiOiAxNzk5NTM1NjAwCn0.dc_X5iR_VP_qT0zsiyj_I_OZ2T9FtRU2BBNWN8Bu4GE'
const supabaseUrl = 'https://wcjcvevbeegkgomjkxbk.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjamN2ZXZiZWVna2dvbWpreGJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4Nzc0MzUsImV4cCI6MjA2OTQ1MzQzNX0.s43Zwktw_Omb9P3zR4BJY4WwESak6J_ZnhOtYlp-DkU';
const supabase = (0, supabase_js_1.createClient)(supabaseUrl, supabaseAnonKey);
// Test database connections on startup
function initializeDatabases() {
    return __awaiter(this, void 0, void 0, function* () {
        console.log('Testing database connections...');
        yield (0, mysql_connection_1.testMySQLConnection)();
        console.log('Database initialization complete.');
    });
}
// Initialize Express app
const app = (0, express_1.default)();
const PORT = process.env.PORT || 3001;
app.use((0, cors_1.default)());
app.use(express_1.default.json());
// Test/Health check endpoint
app.get('/api/test', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'Backend server is running',
        timestamp: new Date().toISOString()
    });
});
// Test expense notification endpoint (for debugging)
app.get('/api/expenses/test', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'Expense notification endpoints are registered',
        endpoints: [
            'POST /api/expenses/notify-submitted',
            'POST /api/expenses/notify-approved',
            'POST /api/expenses/notify-rejected'
        ],
        timestamp: new Date().toISOString()
    });
});
// Test email endpoint
app.post('/api/test-email', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { email } = req.body;
        if (!email) {
            return res.status(400).json({
                success: false,
                message: 'Email address is required'
            });
        }
        const result = yield (0, email_service_1.sendTestEmailToAddress)(email);
        if (result.success) {
            return res.status(200).json(result);
        }
        else {
            return res.status(400).json(result);
        }
    }
    catch (error) {
        console.error('Error in test email endpoint:', error);
        return res.status(500).json({
            success: false,
            message: error.message || 'Internal server error'
        });
    }
}));
// ============================================
// Web Push Notification Endpoints
// ============================================
// Get public VAPID key
app.get("/api/public-vapid-key", (req, res) => {
    try {
        const publicKey = (0, web_push_service_1.getPublicVapidKey)();
        res.json({
            success: true,
            publicKey: publicKey
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: error.message || "Failed to get VAPID key"
        });
    }
});
// Subscribe to push notifications
app.post("/api/subscribe", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { userId, subscription, deviceInfo } = req.body;
        if (!userId || !subscription || !subscription.endpoint || !subscription.keys) {
            return res.status(400).json({
                success: false,
                message: "userId, subscription.endpoint, and subscription.keys are required"
            });
        }
        const result = yield (0, web_push_service_1.subscribeUser)(userId, subscription, deviceInfo);
        if (result.success) {
            res.status(200).json(result);
        }
        else {
            res.status(400).json(result);
        }
    }
    catch (error) {
        console.error("Error in subscribe endpoint:", error);
        res.status(500).json({
            success: false,
            message: error.message || "Internal server error"
        });
    }
}));
// Unsubscribe from push notifications
app.post("/api/unsubscribe", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { endpoint } = req.body;
        if (!endpoint) {
            return res.status(400).json({
                success: false,
                message: "endpoint is required"
            });
        }
        const result = yield (0, web_push_service_1.unsubscribeUser)(endpoint);
        if (result.success) {
            res.status(200).json(result);
        }
        else {
            res.status(400).json(result);
        }
    }
    catch (error) {
        console.error("Error in unsubscribe endpoint:", error);
        res.status(500).json({
            success: false,
            message: error.message || "Internal server error"
        });
    }
}));
// ============================================
// Notification Management Endpoints
// ============================================
// Get notifications for a user
app.get("/api/notifications", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const userId = req.query.userId;
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;
        const unreadOnly = req.query.unreadOnly === 'true';
        if (!userId) {
            return res.status(400).json({
                success: false,
                message: "userId is required"
            });
        }
        let query = supabase
            .from("notifications")
            .select("*")
            .eq("user_id", userId)
            .eq("is_deleted", false)
            .order("created_at", { ascending: false })
            .range(offset, offset + limit - 1);
        if (unreadOnly) {
            // Treat NULL is_read as unread (false)
            query = query.or("is_read.is.null,is_read.eq.false");
        }
        const { data, error } = yield query;
        if (error) {
            throw error;
        }
        // Get unread count (treat NULL is_read as unread)
        const { count: unreadCount } = yield supabase
            .from("notifications")
            .select("*", { count: "exact", head: true })
            .eq("user_id", userId)
            .eq("is_deleted", false)
            .or("is_read.is.null,is_read.eq.false");
        // Ensure all notifications have is_read set (default to false if null)
        const normalizedNotifications = (data || []).map((n) => {
            var _a;
            return (Object.assign(Object.assign({}, n), { is_read: (_a = n.is_read) !== null && _a !== void 0 ? _a : false }));
        });
        res.json({
            success: true,
            notifications: normalizedNotifications,
            unreadCount: unreadCount || 0
        });
    }
    catch (error) {
        console.error("Error fetching notifications:", error);
        res.status(500).json({
            success: false,
            message: error.message || "Failed to fetch notifications"
        });
    }
}));
// Mark notification as read
app.patch("/api/notifications/mark-read", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { notificationId, userId } = req.body;
        if (!notificationId || !userId) {
            return res.status(400).json({
                success: false,
                message: "notificationId and userId are required"
            });
        }
        const { data, error } = yield supabase
            .from("notifications")
            .update({
            is_read: true,
            read_at: new Date().toISOString()
        })
            .eq("id", notificationId)
            .eq("user_id", userId)
            .select()
            .single();
        if (error) {
            throw error;
        }
        res.json({
            success: true,
            notification: data
        });
    }
    catch (error) {
        console.error("Error marking notification as read:", error);
        res.status(500).json({
            success: false,
            message: error.message || "Failed to mark notification as read"
        });
    }
}));
// Mark all notifications as read for a user
app.patch("/api/notifications/mark-all-read", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { userId } = req.body;
        if (!userId) {
            return res.status(400).json({
                success: false,
                message: "userId is required"
            });
        }
        const { data, error } = yield supabase
            .from("notifications")
            .update({
            is_read: true,
            read_at: new Date().toISOString()
        })
            .eq("user_id", userId)
            .eq("is_read", false)
            .eq("is_deleted", false)
            .select();
        if (error) {
            throw error;
        }
        res.json({
            success: true,
            updatedCount: (data === null || data === void 0 ? void 0 : data.length) || 0
        });
    }
    catch (error) {
        console.error("Error marking all notifications as read:", error);
        res.status(500).json({
            success: false,
            message: error.message || "Failed to mark all notifications as read"
        });
    }
}));
// ============================================
// Low Stock Notification Endpoint (for testing/manual trigger)
// ============================================
// Trigger low stock notification check (for testing)
app.post("/api/inventory/check-low-stock", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { inventoryItemId, branchId, quantity, itemName, minThreshold } = req.body;
        if (!inventoryItemId) {
            return res.status(400).json({
                success: false,
                message: "inventoryItemId is required"
            });
        }
        // If quantity and item details are provided, use them directly (avoids RLS and timing issues)
        const result = yield (0, low_stock_notification_service_1.checkAndNotifyLowStock)(inventoryItemId, branchId, quantity, itemName, minThreshold);
        if (result.success) {
            res.status(200).json(result);
        }
        else {
            res.status(400).json(result);
        }
    }
    catch (error) {
        console.error("Error checking low stock:", error);
        res.status(500).json({
            success: false,
            message: error.message || "Internal server error"
        });
    }
}));
// ============================================
// Expense Notification Endpoints
// ============================================
// Notify when expense is submitted/added
app.post("/api/expenses/notify-submitted", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { expenseId, expenseNumber, amount, description, categoryName, submittedBy, branchId } = req.body;
        if (!expenseId || !expenseNumber || amount === undefined || !description) {
            return res.status(400).json({
                success: false,
                message: "expenseId, expenseNumber, amount, and description are required"
            });
        }
        const result = yield (0, expense_notification_service_1.notifyExpenseSubmitted)(expenseId, expenseNumber, amount, description, categoryName, submittedBy, branchId);
        if (result.success) {
            res.status(200).json(result);
        }
        else {
            res.status(400).json(result);
        }
    }
    catch (error) {
        console.error("Error notifying expense submission:", error);
        res.status(500).json({
            success: false,
            message: error.message || "Internal server error"
        });
    }
}));
// Notify when expense is approved
app.post("/api/expenses/notify-approved", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { expenseId, expenseNumber, amount, description, categoryName, approvedBy, branchId } = req.body;
        if (!expenseId || !expenseNumber || amount === undefined || !description) {
            return res.status(400).json({
                success: false,
                message: "expenseId, expenseNumber, amount, and description are required"
            });
        }
        const result = yield (0, expense_notification_service_1.notifyExpenseApproved)(expenseId, expenseNumber, amount, description, categoryName, approvedBy, branchId);
        if (result.success) {
            res.status(200).json(result);
        }
        else {
            res.status(400).json(result);
        }
    }
    catch (error) {
        console.error("Error notifying expense approval:", error);
        res.status(500).json({
            success: false,
            message: error.message || "Internal server error"
        });
    }
}));
// Notify when expense is rejected
app.post("/api/expenses/notify-rejected", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { expenseId, expenseNumber, amount, description, rejectionReason, categoryName, rejectedBy, branchId } = req.body;
        if (!expenseId || !expenseNumber || amount === undefined || !description) {
            return res.status(400).json({
                success: false,
                message: "expenseId, expenseNumber, amount, and description are required"
            });
        }
        const result = yield (0, expense_notification_service_1.notifyExpenseRejected)(expenseId, expenseNumber, amount, description, rejectionReason, categoryName, rejectedBy, branchId);
        if (result.success) {
            res.status(200).json(result);
        }
        else {
            res.status(400).json(result);
        }
    }
    catch (error) {
        console.error("Error notifying expense rejection:", error);
        res.status(500).json({
            success: false,
            message: error.message || "Internal server error"
        });
    }
}));
// Health check endpoint
app.get("/api/health", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        res.json({
            status: "ok",
            timestamp: new Date().toISOString(),
        });
    }
    catch (error) {
        res.status(500).json({
            status: "error",
            error: error.message,
        });
    }
}));
// Start Express server
app.listen(PORT, () => {
    console.log(`Express server running on port ${PORT}`);
});
// Initialize databases
initializeDatabases();
// Start punch sync cron job (every minute)
node_cron_1.default.schedule('* * * * *', () => {
    console.log('Running punch sync...');
    (0, punch_sync_1.syncPunchRecords)();
});
// Run punch sync immediately on startup
(0, punch_sync_1.syncPunchRecords)();
function processAttendanceForDate(targetDate) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        try {
            console.log(`Processing attendance for ${targetDate}...`);
            // Get punch records from database for the target date
            const { data: punchRecords, error: punchError } = yield supabase
                .from("punch_records")
                .select("enroll_number, punch_time")
                .gte("punch_time", `${targetDate} 00:00:00`)
                .lt("punch_time", `${(0, dayjs_1.default)(targetDate).add(1, "day").format("YYYY-MM-DD")} 00:00:00`)
                .order("punch_time", { ascending: true });
            if (punchError)
                throw punchError;
            if (!punchRecords || punchRecords.length === 0) {
                console.log("No punch records found for the date");
                return;
            }
            console.log(`Found ${punchRecords.length} punch records`);
            // Convert to PunchData format
            const punchData = punchRecords.map(record => ({
                enroll_number: record.enroll_number,
                punch_time: (0, dayjs_1.default)(record.punch_time)
            }));
            const enrollNumbers = [...new Set(punchData.map((p) => p.enroll_number))];
            console.log(`Processing attendance for ${enrollNumbers.length} unique employees`);
            for (const enrollNumber of enrollNumbers) {
                console.log(`Processing enroll number: ${enrollNumber}`);
                const punches = punchData
                    .filter((p) => p.enroll_number === enrollNumber)
                    .sort((a, b) => a.punch_time.valueOf() - b.punch_time.valueOf());
                if (punches.length === 0)
                    continue;
                const { data: profile, error: profileErr } = yield supabase.from("user_profiles").select("id").eq("biometric_code", enrollNumber).single();
                if (profileErr || !profile) {
                    console.log(`Profile not found for ${enrollNumber}`);
                    continue;
                }
                const { data: emp, error: empErr } = yield supabase.from("employees").select("id").eq("user_id", profile.id).single();
                if (empErr || !emp) {
                    console.log(`Employee not found for user_id ${profile.id}`);
                    continue;
                }
                const userProfileId = profile.id;
                const employeeId = emp.id;
                const attendanceDate = punches[0].punch_time.format("YYYY-MM-DD");
                // Check if attendance already exists
                const { data: existingAttendance } = yield supabase
                    .from("attendance_records")
                    .select("id")
                    .eq("user_profile_id", userProfileId)
                    .eq("attendance_date", attendanceDate)
                    .single();
                if (existingAttendance) {
                    console.log(`Attendance already exists for ${enrollNumber} on ${attendanceDate}`);
                    continue;
                }
                const checkIn = punches[0].punch_time;
                let checkOut = punches.length > 1 ? punches[punches.length - 1].punch_time : null;
                // If only check-in exists, estimate check-out based on shift or default 8 hours
                if (!checkOut || punches.length === 1) {
                    console.log(`Only check-in found for ${enrollNumber}, estimating check-out time`);
                    checkOut = checkIn.add(8, 'hour'); // Default 8-hour shift
                }
                let totalBreakMs = 0;
                if (punches.length > 2) {
                    for (let i = 1; i < punches.length - 1; i += 2) {
                        const breakStart = punches[i].punch_time;
                        const breakEnd = punches[i + 1].punch_time;
                        totalBreakMs += breakEnd.diff(breakStart, 'millisecond');
                    }
                }
                const totalBreakMinutes = Math.round(totalBreakMs / (1000 * 60));
                const totalWorkMs = checkOut.diff(checkIn, 'millisecond') - totalBreakMs;
                const totalHours = parseFloat((totalWorkMs / (1000 * 60 * 60)).toFixed(2));
                // --- DEBUG: Check what employee_shifts exist ---
                const { data: allShifts } = yield supabase
                    .from("employee_shifts")
                    .select("*")
                    .eq("employee_id", employeeId);
                console.log(`All shifts for employee ${employeeId}:`, allShifts);
                // --- SHIFT-BASED LOGIC INITIALIZATION ---
                const { data: shift, error: shiftErr } = yield supabase
                    .from("employee_shifts")
                    .select("shift_id, shifts(start_time, end_time, grace_period)")
                    .eq("employee_id", employeeId)
                    .eq("is_active", true)
                    .eq("is_deleted", false)
                    .maybeSingle();
                console.log(`Shift query result for employee ${employeeId}:`, { shift, shiftErr });
                let lateArrivalMinutes = 0;
                let consecutiveLateCount = 0;
                let halfDayPenalty = false;
                let earlyDepartureMinutes = 0;
                let overtimeHours = 0;
                if (!shiftErr && (shift === null || shift === void 0 ? void 0 : shift.shifts)) {
                    // --- SHIFT WAS FOUND, CALCULATE EVERYTHING BASED ON IT ---
                    console.log(`Shift found for employee ${enrollNumber}. Using shift-based calculations.`);
                    const actualShift = shift.shifts;
                    // If only check-in exists, use shift end time for check-out estimation
                    if (punches.length === 1) {
                        const shiftEndTime = (0, dayjs_1.default)(`${attendanceDate} ${actualShift.end_time}`);
                        checkOut = shiftEndTime;
                        const totalWorkMs = checkOut.diff(checkIn, 'millisecond');
                        const totalHours = parseFloat((totalWorkMs / (1000 * 60 * 60)).toFixed(2));
                        console.log(`Using shift end time for check-out: ${checkOut.format('HH:mm:ss')}`);
                    }
                    // 1. LATE ARRIVAL CALCULATION
                    const shiftStartTime = (0, dayjs_1.default)(`${attendanceDate} ${actualShift.start_time}`);
                    const gracePeriod = actualShift.grace_period || 5;
                    if (checkIn.isAfter(shiftStartTime.add(gracePeriod, "minute"))) {
                        lateArrivalMinutes = checkIn.diff(shiftStartTime, "minute");
                        // Consecutive late logic...
                        const { data: lastAttendance } = yield supabase.from("attendance_records").select("consecutive_late_count").eq("user_profile_id", userProfileId).order("attendance_date", { ascending: false }).limit(1);
                        consecutiveLateCount = (((_a = lastAttendance === null || lastAttendance === void 0 ? void 0 : lastAttendance[0]) === null || _a === void 0 ? void 0 : _a.consecutive_late_count) || 0) + 1;
                        if (consecutiveLateCount >= 3) {
                            halfDayPenalty = true;
                            consecutiveLateCount = 0; // Reset after penalty
                        }
                    }
                    // 2. EARLY DEPARTURE CALCULATION
                    const shiftEndTime = (0, dayjs_1.default)(`${attendanceDate} ${actualShift.end_time}`);
                    if (checkOut.isBefore(shiftEndTime)) {
                        earlyDepartureMinutes = shiftEndTime.diff(checkOut, "minute");
                    }
                    // 3. SHIFT-BASED OVERTIME CALCULATION
                    const shiftStart = (0, dayjs_1.default)(`${attendanceDate} ${actualShift.start_time}`);
                    const shiftEnd = (0, dayjs_1.default)(`${attendanceDate} ${actualShift.end_time}`);
                    const shiftDurationHours = shiftEnd.diff(shiftStart, 'hour', true);
                    const requiredWorkHours = shiftDurationHours - 0.5; // Assuming a 30-minute break
                    if (totalHours > shiftDurationHours) {
                        overtimeHours = parseFloat((totalHours - shiftDurationHours).toFixed(2));
                    }
                }
                else {
                    // --- NO SHIFT FOUND, USE DEFAULTS ---
                    console.log(`No shift found for employee ${enrollNumber}. Using default calculations.`);
                    const standardWorkHours = 8.5;
                    if (totalHours > standardWorkHours) {
                        overtimeHours = parseFloat((totalHours - standardWorkHours).toFixed(2));
                    }
                }
                // Provide all calculated fields to avoid trigger issues
                const attendanceData = {
                    user_profile_id: userProfileId,
                    attendance_date: attendanceDate,
                    check_in: checkIn.format('YYYY-MM-DD HH:mm:ss'),
                    check_out: checkOut.format('YYYY-MM-DD HH:mm:ss'),
                    total_break_duration_minutes: totalBreakMinutes,
                    total_hours: totalHours,
                    overtime_hours: overtimeHours,
                    status: "present",
                    late_arrival_minutes: lateArrivalMinutes,
                    early_departure_minutes: earlyDepartureMinutes,
                    consecutive_late_count: consecutiveLateCount,
                    half_day_penalty: halfDayPenalty,
                    actual_work_hours: totalHours,
                    is_manual_entry: false,
                    grace_period_minutes: 5
                };
                console.log(`Attempting to insert data:`, attendanceData);
                const { error: attErr } = yield supabase
                    .from("attendance_records")
                    .insert(attendanceData);
                if (attErr) {
                    console.error(`Error inserting attendance:`, JSON.stringify(attErr, null, 2));
                }
                else {
                    console.log(`Successfully inserted attendance for user_profile ${userProfileId}`);
                }
            }
            console.log("Attendance processing completed.");
        }
        catch (err) {
            console.error("Error:", err);
        }
    });
}
function processAttendance() {
    return __awaiter(this, void 0, void 0, function* () {
        const targetDate = (0, dayjs_1.default)().subtract(1, "day").format("YYYY-MM-DD");
        yield processAttendanceForDate(targetDate);
    });
}
function processAttendanceForDateRange(startDate, endDate) {
    return __awaiter(this, void 0, void 0, function* () {
        const start = (0, dayjs_1.default)(startDate);
        const end = (0, dayjs_1.default)(endDate);
        let currentDate = start;
        while (currentDate.isBefore(end) || currentDate.isSame(end)) {
            const dateStr = currentDate.format('YYYY-MM-DD');
            console.log(`Processing attendance for ${dateStr}`);
            yield processAttendanceForDate(dateStr);
            currentDate = currentDate.add(1, 'day');
        }
    });
}
function processAttendanceForDateRangeAndUser(startDate, endDate, enrollNumber) {
    return __awaiter(this, void 0, void 0, function* () {
        const start = (0, dayjs_1.default)(startDate);
        const end = (0, dayjs_1.default)(endDate);
        let currentDate = start;
        while (currentDate.isBefore(end) || currentDate.isSame(end)) {
            const dateStr = currentDate.format('YYYY-MM-DD');
            console.log(`Processing attendance for user ${enrollNumber} on ${dateStr}`);
            yield processAttendanceForUserAndDate(dateStr, enrollNumber);
            currentDate = currentDate.add(1, 'day');
        }
    });
}
// One-time function to process current month attendance
// async function processCurrentMonthOnce() {
//   const currentMonth = dayjs().format('YYYY-MM');
//   const startDate = dayjs(currentMonth + '-01');
//   const today = dayjs();
//   console.log(`One-time processing for month: ${currentMonth}`);
//   let currentDate = startDate;
//   while (currentDate.isBefore(today) || currentDate.isSame(today, 'day')) {
//     const dateStr = currentDate.format('YYYY-MM-DD');
//     console.log(`\n=== One-time processing ${dateStr} ===`);
//     await processAttendanceForDate(dateStr);
//     currentDate = currentDate.add(1, 'day');
//   }
//   console.log('\nOne-time current month processing completed!');
// }
// // Run one-time current month processing
// processCurrentMonthOnce();
// Process attendance for date range
// async function processSpecificDateRange() {
//   const startDate = '2025-08-01';
//   const endDate = '2025-08-31';
//   console.log(`Processing attendance for date range: ${startDate} to ${endDate}`);
//   await processAttendanceForDateRange(startDate, endDate);
// }
// Run for date range
// processSpecificDateRange();
// Schedule to run daily at midnight
node_cron_1.default.schedule('0 0 * * *', () => {
    console.log("Running daily attendance processing...");
    processAttendance();
});
// Schedule event notification check daily at 9 AM
node_cron_1.default.schedule('0 9 * * *', () => {
    console.log("Running event notification check...");
    (0, event_notification_service_1.sendEventNotifications)();
});
// Function to calculate attendance for specific user and date
function processAttendanceForUserAndDate(targetDate, enrollNumber) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        try {
            console.log(`Processing attendance for user ${enrollNumber} on ${targetDate}...`);
            // Get punch records for specific user and date
            const { data: punchRecords, error: punchError } = yield supabase
                .from("punch_records")
                .select("enroll_number, punch_time")
                .eq("enroll_number", enrollNumber)
                .gte("punch_time", `${targetDate} 00:00:00`)
                .lt("punch_time", `${(0, dayjs_1.default)(targetDate).add(1, "day").format("YYYY-MM-DD")} 00:00:00`)
                .order("punch_time", { ascending: true });
            if (punchError)
                throw punchError;
            if (!punchRecords || punchRecords.length === 0) {
                console.log(`No punch records found for user ${enrollNumber} on ${targetDate}`);
                return;
            }
            console.log(`Found ${punchRecords.length} punch records for user ${enrollNumber}`);
            // Convert to PunchData format
            const punchData = punchRecords.map(record => ({
                enroll_number: record.enroll_number,
                punch_time: (0, dayjs_1.default)(record.punch_time)
            }));
            const punches = punchData.sort((a, b) => a.punch_time.valueOf() - b.punch_time.valueOf());
            const { data: profile, error: profileErr } = yield supabase.from("user_profiles").select("id").eq("biometric_code", enrollNumber).single();
            if (profileErr || !profile) {
                console.log(`Profile not found for ${enrollNumber}`);
                return;
            }
            const { data: emp, error: empErr } = yield supabase.from("employees").select("id").eq("user_id", profile.id).single();
            if (empErr || !emp) {
                console.log(`Employee not found for user_id ${profile.id}`);
                return;
            }
            const userProfileId = profile.id;
            const employeeId = emp.id;
            const attendanceDate = punches[0].punch_time.format("YYYY-MM-DD");
            // Check if attendance already exists
            const { data: existingAttendance } = yield supabase
                .from("attendance_records")
                .select("id")
                .eq("user_profile_id", userProfileId)
                .eq("attendance_date", attendanceDate)
                .single();
            if (existingAttendance) {
                console.log(`Attendance already exists for ${enrollNumber} on ${attendanceDate}`);
                return;
            }
            const checkIn = punches[0].punch_time;
            let checkOut = punches.length > 1 ? punches[punches.length - 1].punch_time : null;
            if (!checkOut || punches.length === 1) {
                console.log(`Only check-in found for ${enrollNumber}, estimating check-out time`);
                checkOut = checkIn.add(8, 'hour');
            }
            let totalBreakMs = 0;
            if (punches.length > 2) {
                for (let i = 1; i < punches.length - 1; i += 2) {
                    const breakStart = punches[i].punch_time;
                    const breakEnd = punches[i + 1].punch_time;
                    totalBreakMs += breakEnd.diff(breakStart, 'millisecond');
                }
            }
            const totalBreakMinutes = Math.round(totalBreakMs / (1000 * 60));
            const totalWorkMs = checkOut.diff(checkIn, 'millisecond') - totalBreakMs;
            const totalHours = parseFloat((totalWorkMs / (1000 * 60 * 60)).toFixed(2));
            const { data: shift, error: shiftErr } = yield supabase
                .from("employee_shifts")
                .select("shift_id, shifts(start_time, end_time, grace_period)")
                .eq("employee_id", employeeId)
                .eq("is_active", true)
                .eq("is_deleted", false)
                .maybeSingle();
            let lateArrivalMinutes = 0;
            let consecutiveLateCount = 0;
            let halfDayPenalty = false;
            let earlyDepartureMinutes = 0;
            let overtimeHours = 0;
            if (!shiftErr && (shift === null || shift === void 0 ? void 0 : shift.shifts)) {
                const actualShift = shift.shifts;
                if (punches.length === 1) {
                    const shiftEndTime = (0, dayjs_1.default)(`${attendanceDate} ${actualShift.end_time}`);
                    checkOut = shiftEndTime;
                }
                const shiftStartTime = (0, dayjs_1.default)(`${attendanceDate} ${actualShift.start_time}`);
                const gracePeriod = actualShift.grace_period || 5;
                if (checkIn.isAfter(shiftStartTime.add(gracePeriod, "minute"))) {
                    lateArrivalMinutes = checkIn.diff(shiftStartTime, "minute");
                    const { data: lastAttendance } = yield supabase.from("attendance_records").select("consecutive_late_count").eq("user_profile_id", userProfileId).order("attendance_date", { ascending: false }).limit(1);
                    consecutiveLateCount = (((_a = lastAttendance === null || lastAttendance === void 0 ? void 0 : lastAttendance[0]) === null || _a === void 0 ? void 0 : _a.consecutive_late_count) || 0) + 1;
                    if (consecutiveLateCount >= 3) {
                        halfDayPenalty = true;
                        consecutiveLateCount = 0;
                    }
                }
                const shiftEndTime = (0, dayjs_1.default)(`${attendanceDate} ${actualShift.end_time}`);
                if (checkOut.isBefore(shiftEndTime)) {
                    earlyDepartureMinutes = shiftEndTime.diff(checkOut, "minute");
                }
                const shiftStart = (0, dayjs_1.default)(`${attendanceDate} ${actualShift.start_time}`);
                const shiftEnd = (0, dayjs_1.default)(`${attendanceDate} ${actualShift.end_time}`);
                const shiftDurationHours = shiftEnd.diff(shiftStart, 'hour', true);
                if (totalHours > shiftDurationHours) {
                    overtimeHours = parseFloat((totalHours - shiftDurationHours).toFixed(2));
                }
            }
            else {
                const standardWorkHours = 8.5;
                if (totalHours > standardWorkHours) {
                    overtimeHours = parseFloat((totalHours - standardWorkHours).toFixed(2));
                }
            }
            const attendanceData = {
                user_profile_id: userProfileId,
                attendance_date: attendanceDate,
                check_in: checkIn.format('YYYY-MM-DD HH:mm:ss'),
                check_out: checkOut.format('YYYY-MM-DD HH:mm:ss'),
                total_break_duration_minutes: totalBreakMinutes,
                total_hours: totalHours,
                overtime_hours: overtimeHours,
                status: "present",
                late_arrival_minutes: lateArrivalMinutes,
                early_departure_minutes: earlyDepartureMinutes,
                consecutive_late_count: consecutiveLateCount,
                half_day_penalty: halfDayPenalty,
                actual_work_hours: totalHours,
                is_manual_entry: false,
                grace_period_minutes: 5
            };
            const { error: attErr } = yield supabase
                .from("attendance_records")
                .insert(attendanceData);
            if (attErr) {
                console.error(`Error inserting attendance:`, JSON.stringify(attErr, null, 2));
            }
            else {
                console.log(`Successfully calculated attendance for user ${enrollNumber} on ${targetDate}`);
            }
        }
        catch (err) {
            console.error("Error:", err);
        }
    });
}
// Calculate attendance for user with enroll_number 123 for January 2025
// processAttendanceForDateRangeAndUser('2025-09-01', '2025-09-31', 2);
// Calculate attendance for all users from 2025-01-01 to 2025-01-31
// processAttendanceForDateRange('2025-07-01', '2025-10-14');
// Export attendance CSV for date range
// exportAttendanceCSV('2025-07-01', '2025-07-31');
// Process attendance from punch records to CSV (like SQL function)
// processAttendanceToCSV('2025-10-11', '2025-10-27');
console.log('Server started - running initial attendance processing...');
