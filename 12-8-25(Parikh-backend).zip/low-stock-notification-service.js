"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendLowStockNotifications = sendLowStockNotifications;
exports.checkAndNotifyLowStock = checkAndNotifyLowStock;
const supabase_js_1 = require("@supabase/supabase-js");
const dotenv_1 = __importDefault(require("dotenv"));
const web_push_service_1 = require("./web-push-service");
dotenv_1.default.config();
// Supabase client
const supabaseUrl = 'https://wcjcvevbeegkgomjkxbk.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjamN2ZXZiZWVna2dvbWpreGJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4Nzc0MzUsImV4cCI6MjA2OTQ1MzQzNX0.s43Zwktw_Omb9P3zR4BJY4WwESak6J_ZnhOtYlp-DkU';
// const supabaseUrl = 'https://api.parikhassociates.in'
// const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyAgCiAgICAicm9sZSI6ICJhbm9uIiwKICAgICJpc3MiOiAic3VwYWJhc2UtZGVtbyIsCiAgICAiaWF0IjogMTY0MTc2OTIwMCwKICAgICJleHAiOiAxNzk5NTM1NjAwCn0.dc_X5iR_VP_qT0zsiyj_I_OZ2T9FtRU2BBNWN8Bu4GE'
const supabase = (0, supabase_js_1.createClient)(supabaseUrl, supabaseAnonKey);
/**
 * Check if a notification was already sent for this item recently
 * This prevents duplicate notifications, but allows re-notification if:
 * 1. Quantity has changed significantly (dropped further), OR
 * 2. More than 24 hours have passed since last notification
 */
function hasNotificationBeenSent(inventoryItemId, currentQuantity) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Check if there's a recent notification for THIS SPECIFIC item in the last 24 hours
            const { data: recentNotifications, error } = yield supabase
                .from('notifications')
                .select('id, data, created_at')
                .eq('type', 'inventory')
                .eq('is_deleted', false)
                .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()) // Last 24 hours
                .order('created_at', { ascending: false });
            if (error) {
                console.error('Error checking existing notifications:', error);
                return false; // If error, allow notification to proceed
            }
            if (!recentNotifications || recentNotifications.length === 0) {
                return false; // No recent notifications found
            }
            // Find notifications for this specific inventory item
            const itemNotifications = recentNotifications.filter(notif => {
                if (!notif.data)
                    return false;
                const notificationInfo = notif.data;
                return notificationInfo.inventory_item_id === inventoryItemId;
            });
            if (itemNotifications.length === 0) {
                return false; // No recent notification for this item
            }
            // Get the most recent notification for this item
            const mostRecent = itemNotifications[0];
            const notificationInfo = mostRecent.data;
            const previousQuantity = notificationInfo.quantity;
            // Allow notification if:
            // 1. Quantity has dropped further (more urgent)
            // 2. More than 24 hours have passed
            // 3. This is a different stock level
            if (currentQuantity < previousQuantity) {
                console.log(`Quantity dropped from ${previousQuantity} to ${currentQuantity}, allowing new notification`);
                return false; // Quantity dropped, allow notification
            }
            // If quantity is the same or higher, check if enough time has passed
            const notificationTime = new Date(mostRecent.created_at).getTime();
            const timeSinceNotification = Date.now() - notificationTime;
            const hoursSinceNotification = timeSinceNotification / (1000 * 60 * 60);
            // Allow re-notification after 24 hours even if quantity is same
            if (hoursSinceNotification >= 24) {
                console.log(`${hoursSinceNotification.toFixed(1)} hours since last notification, allowing re-notification`);
                return false;
            }
            // Same item, same or higher quantity, within 24 hours - don't send duplicate
            console.log(`Notification already sent for item ${inventoryItemId} at quantity ${currentQuantity} (previous: ${previousQuantity}) ${hoursSinceNotification.toFixed(1)} hours ago`);
            return true;
        }
        catch (error) {
            console.error('Error in hasNotificationBeenSent:', error);
            return false; // If error, allow notification to proceed
        }
    });
}
/**
 * Send low stock notifications to Admin, HR Manager, Manager, and HR users
 */
function sendLowStockNotifications(notificationData) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { inventoryItemId, itemName, currentQuantity, minThreshold, branchId } = notificationData;
            // Check if notification was already sent for this quantity
            const alreadySent = yield hasNotificationBeenSent(inventoryItemId, currentQuantity);
            if (alreadySent) {
                console.log(`Notification already sent for item ${itemName} at quantity ${currentQuantity}`);
                return {
                    success: true,
                    message: 'Notification already sent for this stock level',
                    notificationsCreated: 0,
                    pushSent: 0
                };
            }
            // Get Admin, Manager, and HR user IDs
            const { data: adminUserIds, error: userError } = yield supabase.rpc('get_admin_user_ids_for_notifications');
            if (userError) {
                console.error('Error fetching admin user IDs:', userError);
                return {
                    success: false,
                    message: `Failed to fetch admin user IDs: ${userError.message}`,
                    notificationsCreated: 0,
                    pushSent: 0
                };
            }
            if (!adminUserIds || adminUserIds.length === 0) {
                console.log('⚠️  No admin/manager/HR users found - notifications will not be sent');
                return {
                    success: true,
                    message: 'No admin/manager/HR users found',
                    notificationsCreated: 0,
                    pushSent: 0
                };
            }
            // Log which users are eligible to receive notifications
            console.log(`\n📋 Found ${adminUserIds.length} eligible user(s) for low stock notifications:`);
            const userIds = adminUserIds.map((row) => row.user_id);
            console.log(`   User IDs: ${userIds.join(', ')}`);
            // Get company logo URL
            let logoUrl = '/logo.png'; // fallback
            try {
                const { data: companySettings } = yield supabase
                    .from('company_settings')
                    .select('logo_url')
                    .single();
                if (companySettings === null || companySettings === void 0 ? void 0 : companySettings.logo_url) {
                    logoUrl = companySettings.logo_url;
                }
            }
            catch (logoError) {
                console.log('Could not fetch company logo, using fallback');
            }
            // Try to get user details (email/name) for better logging
            try {
                const { data: userDetails } = yield supabase
                    .from('users')
                    .select('id, email, full_name')
                    .in('id', userIds);
                if (userDetails && userDetails.length > 0) {
                    console.log(`\n👥 Eligible users details:`);
                    userDetails.forEach((user) => {
                        console.log(`   - ${user.email || user.id} (${user.full_name || 'No name'})`);
                    });
                }
            }
            catch (detailError) {
                console.log('   (Could not fetch user details for logging)');
            }
            // Prepare notification message
            const message = `⚠️ Stock Alert: '${itemName}' is running low! Only ${currentQuantity} units remaining (minimum required: ${minThreshold}).`;
            // Prepare notification data for database
            const notificationsToInsert = adminUserIds.map((row) => ({
                user_id: row.user_id,
                title: 'Low Stock Alert',
                message: message,
                type: 'inventory',
                action_url: `/inventory?tab=alerts`,
                data: {
                    inventory_item_id: inventoryItemId,
                    item_name: itemName,
                    quantity: currentQuantity,
                    min_threshold: minThreshold,
                    branch_id: branchId,
                    reference_type: 'low_stock'
                }
            }));
            // Insert notifications into database
            const { data: insertedNotifications, error: insertError } = yield supabase.rpc('insert_notifications_for_users', {
                p_notifications: notificationsToInsert
            });
            if (insertError) {
                console.error('Error inserting notifications:', insertError);
                return {
                    success: false,
                    message: `Failed to insert notifications: ${insertError.message}`,
                    notificationsCreated: 0,
                    pushSent: 0
                };
            }
            const notificationsCreated = (insertedNotifications === null || insertedNotifications === void 0 ? void 0 : insertedNotifications.length) || 0;
            console.log(`\n✅ Created ${notificationsCreated} notification(s) in database for low stock alert`);
            if (notificationsCreated === 0) {
                console.log(`   ⚠️  WARNING: No notifications were created in database!`);
            }
            else if (notificationsCreated < userIds.length) {
                console.log(`   ⚠️  WARNING: Expected ${userIds.length} notifications but only ${notificationsCreated} were created`);
            }
            // Send push notifications
            console.log(`\n📲 Sending push notifications to ${userIds.length} user(s)...`);
            const pushResult = yield (0, web_push_service_1.sendPushNotificationsToUsers)(userIds, {
                title: 'Low Stock Alert',
                message: message,
                url: `/inventory?tab=alerts `,
                icon: logoUrl,
                badge: logoUrl
            });
            console.log(`\n📊 Push Notification Summary:`);
            console.log(`   ✅ Successfully sent: ${pushResult.success}`);
            console.log(`   ❌ Failed: ${pushResult.failed}`);
            if (pushResult.errors && pushResult.errors.length > 0) {
                console.log(`\n   ❌ Push notification errors:`);
                pushResult.errors.forEach((error, index) => {
                    console.log(`      ${index + 1}. ${error}`);
                });
            }
            if (pushResult.success === 0 && userIds.length > 0) {
                console.log(`\n   ⚠️  WARNING: No push notifications were sent!`);
                console.log(`   Possible reasons:`);
                console.log(`   - Users have not subscribed to push notifications`);
                console.log(`   - Push subscriptions are invalid or expired`);
                console.log(`   - VAPID keys are not configured correctly`);
            }
            return {
                success: true,
                message: `Notifications created and push notifications sent`,
                notificationsCreated: notificationsCreated,
                pushSent: pushResult.success
            };
        }
        catch (error) {
            console.error('Error in sendLowStockNotifications:', error);
            return {
                success: false,
                message: error.message || 'Failed to send low stock notifications',
                notificationsCreated: 0,
                pushSent: 0
            };
        }
    });
}
/**
 * Check inventory item after issuance and send notification if low stock
 * This should be called after an inventory item is issued
 */
function checkAndNotifyLowStock(inventoryItemId, branchId, providedQuantity, providedItemName, providedMinThreshold) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let item = null;
            // If quantity and item details are provided, use them (avoids RLS issues and timing problems)
            if (providedQuantity !== undefined && providedItemName && providedMinThreshold !== undefined) {
                item = {
                    id: inventoryItemId,
                    name: providedItemName,
                    quantity: providedQuantity,
                    min_threshold: providedMinThreshold,
                    status: 'active'
                };
                console.log(`Using provided item data for ${providedItemName}: quantity=${providedQuantity}, threshold=${providedMinThreshold}`);
            }
            else {
                // Otherwise, fetch from database (with retry for timing issues)
                let retries = 3;
                let itemError = null;
                while (retries > 0) {
                    const { data, error } = yield supabase
                        .from('inventory_items')
                        .select('id, name, quantity, min_threshold, status')
                        .eq('id', inventoryItemId)
                        .maybeSingle();
                    if (!error && data) {
                        item = data;
                        break;
                    }
                    itemError = error;
                    retries--;
                    if (retries > 0) {
                        // Wait a bit for database trigger to complete
                        yield new Promise(resolve => setTimeout(resolve, 500));
                    }
                }
                if (itemError) {
                    console.error('Error fetching inventory item:', itemError);
                    return {
                        success: false,
                        message: `Failed to fetch inventory item: ${itemError.message}`,
                        notificationSent: false
                    };
                }
                if (!item) {
                    console.error('Inventory item not found after retries:', inventoryItemId);
                    return {
                        success: false,
                        message: `Inventory item not found: ${inventoryItemId}`,
                        notificationSent: false
                    };
                }
            }
            // Check if quantity is at or below minimum threshold
            if (item.quantity <= item.min_threshold) {
                console.log(`Low stock detected for item ${item.name}: ${item.quantity} <= ${item.min_threshold}`);
                const result = yield sendLowStockNotifications({
                    inventoryItemId: item.id,
                    itemName: item.name,
                    currentQuantity: item.quantity,
                    minThreshold: item.min_threshold,
                    branchId: branchId
                });
                return {
                    success: result.success,
                    message: result.message,
                    notificationSent: result.notificationsCreated > 0
                };
            }
            return {
                success: true,
                message: 'Stock level is above threshold',
                notificationSent: false
            };
        }
        catch (error) {
            console.error('Error in checkAndNotifyLowStock:', error);
            return {
                success: false,
                message: error.message || 'Failed to check low stock',
                notificationSent: false
            };
        }
    });
}
