"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mysqlPool = void 0;
exports.testMySQLConnection = testMySQLConnection;
const promise_1 = __importDefault(require("mysql2/promise"));
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
// MySQL connection configuration
// const mysqlConfig = {
//   host: process.env.MYSQL_HOST || '82.180.147.190',
//   port: parseInt(process.env.MYSQL_PORT || '3306'),
//   user: process.env.MYSQL_USER || 'root',
//   password: process.env.MYSQL_PASSWORD || 'Biomax@123',
//   database: process.env.MYSQL_DATABASE || 'dmps',
//   waitForConnections: true,
//   connectionLimit: 10,
//   queueLimit: 0
// };
const mysqlConfig = {
    host: process.env.MYSQL_HOST || '192.168.29.105',
    port: parseInt(process.env.MYSQL_PORT || '3306'),
    user: process.env.MYSQL_USER || 'root',
    password: process.env.MYSQL_PASSWORD || 'Native#2021',
    database: process.env.MYSQL_DATABASE || 'dmps',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
};
// Create MySQL connection pool
exports.mysqlPool = promise_1.default.createPool(mysqlConfig);
// Test MySQL connection
function testMySQLConnection() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const connection = yield exports.mysqlPool.getConnection();
            console.log('MySQL connected successfully');
            connection.release();
            return true;
        }
        catch (error) {
            console.log('MySQL connection failed:', error.message);
            return false;
        }
    });
}
