"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncPunchRecords = syncPunchRecords;
exports.syncAllPunchRecords = syncAllPunchRecords;
exports.syncPunchRecordsByDateRange = syncPunchRecordsByDateRange;
exports.syncPunchRecordsByDateRangeAndUserId = syncPunchRecordsByDateRangeAndUserId;
const mysql_connection_1 = require("./mysql-connection");
const supabase_js_1 = require("@supabase/supabase-js");
const dayjs_1 = __importDefault(require("dayjs"));
const utc_1 = __importDefault(require("dayjs/plugin/utc"));
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
dayjs_1.default.extend(utc_1.default);
// const supabaseUrl = 'https://api.parikhassociates.in'
// const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyAgCiAgICAicm9sZSI6ICJhbm9uIiwKICAgICJpc3MiOiAic3VwYWJhc2UtZGVtbyIsCiAgICAiaWF0IjogMTY0MTc2OTIwMCwKICAgICJleHAiOiAxNzk5NTM1NjAwCn0.dc_X5iR_VP_qT0zsiyj_I_OZ2T9FtRU2BBNWN8Bu4GE'
const supabaseUrl = 'https://wcjcvevbeegkgomjkxbk.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjamN2ZXZiZWVna2dvbWpreGJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4Nzc0MzUsImV4cCI6MjA2OTQ1MzQzNX0.s43Zwktw_Omb9P3zR4BJY4WwESak6J_ZnhOtYlp-DkU';
const supabase = (0, supabase_js_1.createClient)(supabaseUrl, supabaseAnonKey);
function syncPunchRecords() {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        try {
            const processId = process.pid;
            const timestamp = new Date().toISOString();
            console.log(`[PID:${processId}] [${timestamp}] Starting punch sync...`);
            const connection = yield mysql_connection_1.mysqlPool.getConnection();
            connection.release();
            // Get the latest MySQL ID that was synced to avoid duplicates (exclude manual entries)
            const { data: latestPunch, error: queryError } = yield supabase
                .from('punch_records')
                .select('mysql_id')
                .not('mysql_id', 'is', null)
                .order('mysql_id', { ascending: false })
                .limit(1);
            console.log(`[PID:${processId}] Supabase query result:`, { data: latestPunch, error: queryError });
            const lastMysqlId = ((_a = latestPunch === null || latestPunch === void 0 ? void 0 : latestPunch[0]) === null || _a === void 0 ? void 0 : _a.mysql_id) || 0;
            console.log(`[PID:${processId}] Last synced MySQL ID: ${lastMysqlId}`);
            // Additional debug: Check total count of punch records
            const { count } = yield supabase
                .from('punch_records')
                .select('*', { count: 'exact', head: true });
            console.log(`[PID:${processId}] Total punch records in database: ${count}`);
            // Query MySQL for new punch records using ID instead of timestamp
            console.log(`[PID:${processId}] Querying MySQL for records with ID > ${lastMysqlId}`);
            const [rows] = yield mysql_connection_1.mysqlPool.execute(`SELECT Id, UserId, IOTime, IOMode, VerifyMode 
       FROM dmps.DeviceLogs 
       WHERE Id > ?
       ORDER BY Id ASC
       LIMIT 10`, [lastMysqlId]);
            if (rows.length > 0) {
                console.log(`[PID:${processId}] MySQL ID range: ${rows[0].Id} to ${rows[rows.length - 1].Id}`);
            }
            console.log(`[PID:${processId}] Found ${rows.length} new MySQL records`);
            if (rows.length === 0) {
                console.log(`[PID:${processId}] No new punch records found`);
                return;
            }
            // Transform MySQL data to Supabase format
            const punchRecords = rows.map(row => ({
                mysql_id: row.Id,
                enroll_number: Number(row.UserId) || 0,
                punch_time: (0, dayjs_1.default)(row.IOTime).format('YYYY-MM-DD HH:mm:ss'),
                in_out_mode: row.IOMode === 'in' ? 1 : (row.IOMode === 'out' ? 0 : (Number(row.IOMode) || null)),
                verify_mode: row.VerifyMode || null
            }));
            // Insert into Supabase with upsert to handle duplicates
            const { error } = yield supabase
                .from('punch_records')
                .upsert(punchRecords, { onConflict: 'mysql_id' });
            if (error) {
                console.error(`[PID:${processId}] Error inserting punch records:`, error);
            }
            else {
                console.log(`[PID:${processId}] Successfully synced ${punchRecords.length} punch records`);
            }
        }
        catch (error) {
            if (error.code === 'ER_ACCESS_DENIED_ERROR') {
                console.log('MySQL access denied - skipping punch sync');
            }
            else {
                console.error('Punch sync error:', error.message);
            }
        }
    });
}
function syncAllPunchRecords() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log('Starting bulk punch sync for all records...');
            const connection = yield mysql_connection_1.mysqlPool.getConnection();
            connection.release();
            // Get all punch records from MySQL
            const [rows] = yield mysql_connection_1.mysqlPool.execute(`SELECT Id, UserId, IOTime, IOMode, VerifyMode 
       FROM dmps.DeviceLogs 
       ORDER BY Id ASC`);
            console.log(`Found ${rows.length} total MySQL records`);
            if (rows.length === 0) {
                console.log('No punch records found in MySQL');
                return;
            }
            // Process in batches of 1000
            const batchSize = 1000;
            let processed = 0;
            for (let i = 0; i < rows.length; i += batchSize) {
                const batch = rows.slice(i, i + batchSize);
                const punchRecords = batch.map(row => ({
                    mysql_id: row.Id,
                    enroll_number: Number(row.UserId) || 0,
                    punch_time: (0, dayjs_1.default)(row.IOTime).format('YYYY-MM-DD HH:mm:ss'),
                    in_out_mode: row.IOMode === 'in' ? 1 : (row.IOMode === 'out' ? 0 : (Number(row.IOMode) || null)),
                    verify_mode: row.VerifyMode || null
                }));
                const { error } = yield supabase
                    .from('punch_records')
                    .upsert(punchRecords, { onConflict: 'mysql_id' });
                if (error) {
                    console.error(`Error inserting batch ${i / batchSize + 1}:`, error);
                }
                else {
                    processed += batch.length;
                    console.log(`Processed ${processed}/${rows.length} records`);
                }
            }
            console.log(`Successfully synced all ${processed} punch records`);
        }
        catch (error) {
            console.error('Bulk punch sync error:', error.message);
        }
    });
}
function syncPunchRecordsByDateRange(startDate, endDate) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log(`=== STARTING DATE RANGE PUNCH SYNC: ${startDate} to ${endDate} ===`);
            const connection = yield mysql_connection_1.mysqlPool.getConnection();
            connection.release();
            const startDateTime = `${startDate} 00:00:00`;
            const endDateTime = `${endDate} 23:59:59`;
            console.log(`Syncing punch records from ${startDateTime} to ${endDateTime}`);
            const [rows] = yield mysql_connection_1.mysqlPool.execute(`SELECT Id, UserId, IOTime, IOMode, VerifyMode 
       FROM dmps.DeviceLogs 
       WHERE IOTime >= ? AND IOTime <= ?
       ORDER BY Id ASC`, [startDateTime, endDateTime]);
            console.log(`Found ${rows.length} MySQL records for date range`);
            if (rows.length === 0) {
                console.log('No punch records found for the specified date range');
                return;
            }
            const batchSize = 1000;
            let processed = 0;
            for (let i = 0; i < rows.length; i += batchSize) {
                const batch = rows.slice(i, i + batchSize);
                const punchRecords = batch.map(row => ({
                    mysql_id: row.Id,
                    enroll_number: Number(row.UserId) || 0,
                    punch_time: (0, dayjs_1.default)(row.IOTime).format('YYYY-MM-DD HH:mm:ss'),
                    in_out_mode: row.IOMode === 'in' ? 1 : (row.IOMode === 'out' ? 0 : (Number(row.IOMode) || null)),
                    verify_mode: row.VerifyMode || null
                }));
                const { error } = yield supabase
                    .from('punch_records')
                    .upsert(punchRecords, { onConflict: 'mysql_id' });
                if (error) {
                    console.error(`Error inserting batch ${i / batchSize + 1}:`, error);
                }
                else {
                    processed += batch.length;
                    console.log(`Processed ${processed}/${rows.length} records`);
                }
            }
            console.log(`=== SUCCESSFULLY SYNCED ${processed} PUNCH RECORDS ===`);
        }
        catch (error) {
            console.error('Date range punch sync error:', error.message);
        }
    });
}
function syncPunchRecordsByDateRangeAndUserId(startDate, endDate, userId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log(`=== STARTING DATE RANGE + USER ID PUNCH SYNC: ${startDate} to ${endDate} for User ID ${userId} ===`);
            const connection = yield mysql_connection_1.mysqlPool.getConnection();
            connection.release();
            const startDateTime = `${startDate} 00:00:00`;
            const endDateTime = `${endDate} 23:59:59`;
            console.log(`Syncing punch records from ${startDateTime} to ${endDateTime} for User ID ${userId}`);
            const [rows] = yield mysql_connection_1.mysqlPool.execute(`SELECT Id, UserId, IOTime, IOMode, VerifyMode 
       FROM dmps.DeviceLogs 
       WHERE IOTime >= ? AND IOTime <= ? AND UserId = ?
       ORDER BY Id ASC`, [startDateTime, endDateTime, userId]);
            console.log(`Found ${rows.length} MySQL records for User ID ${userId} in date range`);
            if (rows.length === 0) {
                console.log(`No punch records found for User ID ${userId} in the specified date range`);
                return;
            }
            const punchRecords = rows.map(row => ({
                mysql_id: row.Id,
                enroll_number: Number(row.UserId) || 0,
                punch_time: (0, dayjs_1.default)(row.IOTime).format('YYYY-MM-DD HH:mm:ss'),
                in_out_mode: row.IOMode === 'in' ? 1 : (row.IOMode === 'out' ? 0 : (Number(row.IOMode) || null)),
                verify_mode: row.VerifyMode || null
            }));
            const { error } = yield supabase
                .from('punch_records')
                .upsert(punchRecords, { onConflict: 'mysql_id' });
            if (error) {
                console.error('Error inserting punch records:', error);
            }
            else {
                console.log(`=== SUCCESSFULLY SYNCED ${punchRecords.length} PUNCH RECORDS FOR USER ID ${userId} ===`);
            }
        }
        catch (error) {
            console.error('Date range + User ID punch sync error:', error.message);
        }
    });
}
