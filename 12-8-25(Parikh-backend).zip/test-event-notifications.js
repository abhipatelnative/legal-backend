"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
const event_notification_service_1 = require("./event-notification-service");
dotenv_1.default.config();
console.log('=== Testing Event Notification System ===\n');
(0, event_notification_service_1.sendEventNotifications)()
    .then(() => {
    console.log('\n✓ Event notification test completed!');
    process.exit(0);
})
    .catch((error) => {
    console.error('\n✗ Error during event notification test:', error);
    process.exit(1);
});
