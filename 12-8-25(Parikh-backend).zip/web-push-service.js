"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPublicVapidKey = getPublicVapidKey;
exports.subscribeUser = subscribeUser;
exports.unsubscribeUser = unsubscribeUser;
exports.sendPushNotification = sendPushNotification;
exports.sendPushNotificationsToUsers = sendPushNotificationsToUsers;
exports.getUserSubscriptions = getUserSubscriptions;
const web_push_1 = __importDefault(require("web-push"));
const supabase_js_1 = require("@supabase/supabase-js");
const dotenv_1 = __importDefault(require("dotenv"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
dotenv_1.default.config();
// Supabase client
const supabaseUrl = 'https://wcjcvevbeegkgomjkxbk.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjamN2ZXZiZWVna2dvbWpreGJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4Nzc0MzUsImV4cCI6MjA2OTQ1MzQzNX0.s43Zwktw_Omb9P3zR4BJY4WwESak6J_ZnhOtYlp-DkU';
// const supabaseUrl = 'https://api.parikhassociates.in';
// const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyAgCiAgICAicm9sZSI6ICJhbm9uIiwKICAgICJpc3MiOiAic3VwYWJhc2UtZGVtbyIsCiAgICAiaWF0IjogMTY0MTc2OTIwMCwKICAgICJleHAiOiAxNzk5NTM1NjAwCn0.dc_X5iR_VP_qT0zsiyj_I_OZ2T9FtRU2BBNWN8Bu4GE';
const supabase = (0, supabase_js_1.createClient)(supabaseUrl, supabaseAnonKey);
// VAPID keys file path
const VAPID_KEYS_PATH = path.join(__dirname, 'vapid-keys.json');
// Initialize VAPID keys
function initializeVapidKeys() {
    let keys;
    // Try to load existing keys
    if (fs.existsSync(VAPID_KEYS_PATH)) {
        try {
            const keysData = fs.readFileSync(VAPID_KEYS_PATH, 'utf-8');
            keys = JSON.parse(keysData);
            console.log('Loaded existing VAPID keys');
        }
        catch (error) {
            console.error('Error reading VAPID keys file, generating new keys...', error);
            keys = generateVapidKeys();
        }
    }
    else {
        console.log('VAPID keys file not found, generating new keys...');
        keys = generateVapidKeys();
    }
    // Set VAPID details for web-push
    web_push_1.default.setVapidDetails('mailto:admin@parikhassociates.in', keys.publicKey, keys.privateKey);
    return keys;
}
// Generate new VAPID keys
function generateVapidKeys() {
    const vapidKeys = web_push_1.default.generateVAPIDKeys();
    const keys = {
        publicKey: vapidKeys.publicKey,
        privateKey: vapidKeys.privateKey
    };
    // Save keys to file
    try {
        fs.writeFileSync(VAPID_KEYS_PATH, JSON.stringify(keys, null, 2));
        console.log('VAPID keys generated and saved to', VAPID_KEYS_PATH);
    }
    catch (error) {
        console.error('Error saving VAPID keys:', error);
    }
    return keys;
}
// Initialize on module load
const vapidKeys = initializeVapidKeys();
// Get public VAPID key
function getPublicVapidKey() {
    return vapidKeys.publicKey;
}
// Subscribe a user to push notifications
function subscribeUser(userId, subscription, deviceInfo) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Call the database function to upsert subscription
            const { data, error } = yield supabase.rpc('upsert_push_subscription', {
                p_endpoint: subscription.endpoint,
                p_p256dh: subscription.keys.p256dh,
                p_auth: subscription.keys.auth,
                p_user_id: userId,
                p_device_info: deviceInfo || null
            });
            if (error) {
                console.error('Error subscribing user:', error);
                return {
                    success: false,
                    message: error.message || 'Failed to subscribe user'
                };
            }
            return {
                success: true,
                message: 'User subscribed successfully',
                id: data
            };
        }
        catch (error) {
            console.error('Error in subscribeUser:', error);
            return {
                success: false,
                message: error.message || 'Failed to subscribe user'
            };
        }
    });
}
// Unsubscribe a user from push notifications
function unsubscribeUser(endpoint) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { error } = yield supabase
                .from('push_subscriptions')
                .delete()
                .eq('endpoint', endpoint);
            if (error) {
                console.error('Error unsubscribing user:', error);
                return {
                    success: false,
                    message: error.message || 'Failed to unsubscribe user'
                };
            }
            return {
                success: true,
                message: 'User unsubscribed successfully'
            };
        }
        catch (error) {
            console.error('Error in unsubscribeUser:', error);
            return {
                success: false,
                message: error.message || 'Failed to unsubscribe user'
            };
        }
    });
}
// Send push notification to a single subscription
function sendPushNotification(subscription, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const notificationPayload = JSON.stringify({
                title: payload.title,
                message: payload.message,
                url: payload.url || '/',
                icon: payload.icon || '/logo.png',
                badge: payload.badge || '/logo.png'
            });
            yield web_push_1.default.sendNotification(subscription, notificationPayload);
            return {
                success: true,
                message: 'Push notification sent successfully'
            };
        }
        catch (error) {
            console.error('Error sending push notification:', error);
            // If subscription is invalid, remove it
            if (error.statusCode === 410 || error.statusCode === 404) {
                try {
                    yield supabase
                        .from('push_subscriptions')
                        .delete()
                        .eq('endpoint', subscription.endpoint);
                    console.log('Removed invalid subscription:', subscription.endpoint);
                }
                catch (deleteError) {
                    console.error('Error removing invalid subscription:', deleteError);
                }
            }
            return {
                success: false,
                message: error.message || 'Failed to send push notification'
            };
        }
    });
}
// Send push notifications to multiple users
function sendPushNotificationsToUsers(userIds, payload) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Get push subscriptions for the users
            const { data: subscriptions, error } = yield supabase.rpc('get_push_subscriptions_for_admin_users', {
                p_admin_user_ids: userIds
            });
            if (error) {
                console.error('Error fetching push subscriptions:', error);
                return {
                    success: 0,
                    failed: userIds.length,
                    errors: [error.message || 'Failed to fetch push subscriptions']
                };
            }
            if (!subscriptions || subscriptions.length === 0) {
                console.log(`   ⚠️  No push subscriptions found for ${userIds.length} user(s)`);
                console.log(`   💡 Users need to allow push notifications in their browser to receive push notifications`);
                // Show which users don't have subscriptions
                const subscribedUserIds = new Set();
                const usersWithoutSubscriptions = userIds.filter(userId => !subscribedUserIds.has(userId));
                if (usersWithoutSubscriptions.length > 0) {
                    console.log(`   📋 Users without push subscriptions: ${usersWithoutSubscriptions.join(', ')}`);
                }
                return {
                    success: 0,
                    failed: 0,
                    errors: []
                };
            }
            // Group subscriptions by user_id
            const subscriptionsByUser = new Map();
            subscriptions.forEach((sub) => {
                if (!subscriptionsByUser.has(sub.user_id)) {
                    subscriptionsByUser.set(sub.user_id, []);
                }
                subscriptionsByUser.get(sub.user_id).push(sub);
            });
            console.log(`   📱 Found ${subscriptions.length} push subscription(s) for ${subscriptionsByUser.size} user(s)`);
            // Check which users have subscriptions and which don't
            const usersWithSubscriptions = Array.from(subscriptionsByUser.keys());
            const usersWithoutSubscriptions = userIds.filter(userId => !usersWithSubscriptions.includes(userId));
            if (usersWithoutSubscriptions.length > 0) {
                console.log(`   ⚠️  ${usersWithoutSubscriptions.length} user(s) without push subscriptions: ${usersWithoutSubscriptions.join(', ')}`);
            }
            let successCount = 0;
            let failedCount = 0;
            const errors = [];
            const successUsers = [];
            const failedUsers = [];
            // Send notification to each subscription
            for (const sub of subscriptions) {
                try {
                    const subscription = {
                        endpoint: sub.endpoint,
                        keys: {
                            p256dh: sub.p256dh,
                            auth: sub.auth
                        }
                    };
                    const result = yield sendPushNotification(subscription, payload);
                    if (result.success) {
                        successCount++;
                        if (!successUsers.includes(sub.user_id)) {
                            successUsers.push(sub.user_id);
                        }
                    }
                    else {
                        failedCount++;
                        if (!failedUsers.includes(sub.user_id)) {
                            failedUsers.push(sub.user_id);
                        }
                        errors.push(`User ${sub.user_id}: ${result.message}`);
                    }
                }
                catch (error) {
                    failedCount++;
                    if (!failedUsers.includes(sub.user_id)) {
                        failedUsers.push(sub.user_id);
                    }
                    errors.push(`User ${sub.user_id}: ${error.message}`);
                }
            }
            // Log summary
            if (successUsers.length > 0) {
                console.log(`   ✅ Push sent successfully to ${successUsers.length} user(s): ${successUsers.join(', ')}`);
            }
            if (failedUsers.length > 0) {
                console.log(`   ❌ Push failed for ${failedUsers.length} user(s): ${failedUsers.join(', ')}`);
            }
            return {
                success: successCount,
                failed: failedCount,
                errors
            };
        }
        catch (error) {
            console.error('Error in sendPushNotificationsToUsers:', error);
            return {
                success: 0,
                failed: userIds.length,
                errors: [error.message || 'Failed to send push notifications']
            };
        }
    });
}
// Get all push subscriptions for a user
function getUserSubscriptions(userId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { data, error } = yield supabase
                .from('push_subscriptions')
                .select('endpoint, p256dh, auth')
                .eq('user_id', userId);
            if (error) {
                console.error('Error fetching user subscriptions:', error);
                return [];
            }
            if (!data || data.length === 0) {
                return [];
            }
            return data.map(sub => ({
                endpoint: sub.endpoint,
                keys: {
                    p256dh: sub.p256dh,
                    auth: sub.auth
                }
            }));
        }
        catch (error) {
            console.error('Error in getUserSubscriptions:', error);
            return [];
        }
    });
}
